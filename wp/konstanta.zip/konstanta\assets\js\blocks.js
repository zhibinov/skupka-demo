(function () {
  "use strict";

  var config = window.KonstantaBlocks || { blocks: [] };
  var el = wp.element.createElement;
  var Fragment = wp.element.Fragment;
  var InspectorControls = wp.blockEditor.InspectorControls;
  var MediaUpload = wp.blockEditor.MediaUpload;
  var MediaUploadCheck = wp.blockEditor.MediaUploadCheck;
  var useBlockProps = wp.blockEditor.useBlockProps;
  var PanelBody = wp.components.PanelBody;
  var TextControl = wp.components.TextControl;
  var TextareaControl = wp.components.TextareaControl;
  var SelectControl = wp.components.SelectControl;
  var ToggleControl = wp.components.ToggleControl;
  var Button = wp.components.Button;
  var Disabled = wp.components.Disabled;
  var ServerSideRender = wp.serverSideRender;

  function mediaUrl(id) {
    if (!id || !wp.media || !wp.media.attachment) {
      return "";
    }
    var attachment = wp.media.attachment(id);
    return attachment && attachment.get ? attachment.get("url") || "" : "";
  }

  function MediaControl(props) {
    return el(
      "div",
      { className: "konstanta-field" },
      el("p", { className: "konstanta-field__label" }, props.label),
      el(
        MediaUploadCheck,
        null,
        el(MediaUpload, {
          allowedTypes: ["image"],
          value: props.value || 0,
          onSelect: function (media) {
            props.onChange(media && media.id ? media.id : 0);
          },
          render: function (obj) {
            var url = mediaUrl(props.value);
            return el(
              Fragment,
              null,
              props.value
                ? el(
                    "div",
                    { className: "konstanta-media" },
                    url
                      ? el("img", { src: url, alt: "" })
                      : el("span", { className: "konstanta-media__stub" }, "Изображение #" + props.value),
                    el(
                      "div",
                      { className: "konstanta-media__actions" },
                      el(Button, { variant: "secondary", onClick: obj.open }, "Заменить"),
                      el(
                        Button,
                        {
                          variant: "link",
                          isDestructive: true,
                          onClick: function () {
                            props.onChange(0);
                          },
                        },
                        "Удалить"
                      )
                    )
                  )
                : el(Button, { variant: "secondary", onClick: obj.open }, "Выбрать изображение")
            );
          },
        })
      )
    );
  }

  function GalleryControl(props) {
    var ids = Array.isArray(props.value) ? props.value : [];

    function removeAt(index) {
      props.onChange(
        ids.filter(function (_, itemIndex) {
          return itemIndex !== index;
        })
      );
    }

    function move(index, direction) {
      var next = ids.slice();
      var target = index + direction;
      if (target < 0 || target >= next.length) {
        return;
      }
      var tmp = next[index];
      next[index] = next[target];
      next[target] = tmp;
      props.onChange(next);
    }

    return el(
      "div",
      { className: "konstanta-field" },
      el("p", { className: "konstanta-field__label" }, props.label),
      el(
        MediaUploadCheck,
        null,
        el(MediaUpload, {
          allowedTypes: ["image"],
          multiple: true,
          gallery: true,
          value: ids,
          onSelect: function (media) {
            var list = Array.isArray(media) ? media : [media];
            props.onChange(
              list
                .filter(function (item) {
                  return item && item.id;
                })
                .map(function (item) {
                  return item.id;
                })
            );
          },
          render: function (obj) {
            return el(
              "div",
              { className: "konstanta-gallery-control" },
              el(Button, { variant: "secondary", onClick: obj.open }, ids.length ? "Изменить фотографии" : "Выбрать фотографии"),
              ids.length
                ? el(
                    "p",
                    { className: "konstanta-help" },
                    "Выбрано фото: " + ids.length + ". Порядок можно менять стрелками."
                  )
                : null,
              ids.length
                ? el(
                    "ul",
                    { className: "konstanta-gallery-list" },
                    ids.map(function (id, index) {
                      var url = mediaUrl(id);
                      return el(
                        "li",
                        { key: id + "-" + index },
                        url ? el("img", { src: url, alt: "" }) : el("span", null, "#" + id),
                        el(
                          "div",
                          { className: "konstanta-gallery-list__actions" },
                          el(
                            Button,
                            {
                              variant: "tertiary",
                              disabled: index === 0,
                              onClick: function () {
                                move(index, -1);
                              },
                              label: "Выше",
                            },
                            "↑"
                          ),
                          el(
                            Button,
                            {
                              variant: "tertiary",
                              disabled: index === ids.length - 1,
                              onClick: function () {
                                move(index, 1);
                              },
                              label: "Ниже",
                            },
                            "↓"
                          ),
                          el(
                            Button,
                            {
                              variant: "link",
                              isDestructive: true,
                              onClick: function () {
                                removeAt(index);
                              },
                            },
                            "Удалить"
                          )
                        )
                      );
                    })
                  )
                : null
            );
          },
        })
      )
    );
  }

  function RepeaterControl(props) {
    var items = Array.isArray(props.items) ? props.items : [];
    var fields = Array.isArray(props.fields) ? props.fields : [];

    function addItem() {
      var item = {};
      fields.forEach(function (field) {
        if (field.type === "select" && field.options && field.options.length) {
          item[field.name] = field.options[0].value;
        } else if (field.type === "number") {
          item[field.name] = 0;
        } else if (field.type === "toggle") {
          item[field.name] = false;
        } else {
          item[field.name] = "";
        }
      });
      props.onChange(items.concat([item]));
    }

    function removeItem(index) {
      props.onChange(
        items.filter(function (_, itemIndex) {
          return itemIndex !== index;
        })
      );
    }

    function moveItem(index, direction) {
      var target = index + direction;
      if (target < 0 || target >= items.length) {
        return;
      }
      var next = items.slice();
      var tmp = next[index];
      next[index] = next[target];
      next[target] = tmp;
      props.onChange(next);
    }

    function updateItem(index, name, value) {
      var next = items.slice();
      next[index] = Object.assign({}, next[index], { [name]: value });
      props.onChange(next);
    }

    return el(
      "div",
      { className: "konstanta-repeater" },
      el(
        "div",
        { className: "konstanta-repeater__head" },
        el("strong", null, props.label),
        el(Button, { variant: "secondary", onClick: addItem }, props.addLabel || "Добавить")
      ),
      items.length === 0
        ? el("p", { className: "konstanta-help" }, "Пока пусто.")
        : items.map(function (item, index) {
            return el(
              "div",
              { className: "konstanta-repeater__item", key: index },
              el(
                "div",
                { className: "konstanta-repeater__item-head" },
                el("span", null, "#" + (index + 1)),
                el(
                  "div",
                  { className: "konstanta-repeater__actions" },
                  el(
                    Button,
                    {
                      variant: "tertiary",
                      disabled: index === 0,
                      onClick: function () {
                        moveItem(index, -1);
                      },
                      label: "Выше",
                    },
                    "↑"
                  ),
                  el(
                    Button,
                    {
                      variant: "tertiary",
                      disabled: index === items.length - 1,
                      onClick: function () {
                        moveItem(index, 1);
                      },
                      label: "Ниже",
                    },
                    "↓"
                  ),
                  el(
                    Button,
                    {
                      variant: "link",
                      isDestructive: true,
                      onClick: function () {
                        removeItem(index);
                      },
                    },
                    "Удалить"
                  )
                )
              ),
              fields.map(function (field) {
                return renderField(field, item, function (name, value) {
                  updateItem(index, name, value);
                }, index + "-" + field.name);
              })
            );
          })
    );
  }

  function renderField(field, values, onChange, key) {
    var value = values[field.name];
    var control;

    if (field.type === "textarea") {
      control = el(TextareaControl, {
        label: field.label,
        value: value || "",
        onChange: function (next) {
          onChange(field.name, next);
        },
        rows: 3,
      });
    } else if (field.type === "select") {
      control = el(SelectControl, {
        label: field.label,
        value: value || "",
        options: field.options || [],
        onChange: function (next) {
          onChange(field.name, next);
        },
      });
    } else if (field.type === "toggle") {
      control = el(ToggleControl, {
        label: field.label,
        checked: !!value,
        onChange: function (next) {
          onChange(field.name, next);
        },
      });
    } else if (field.type === "media") {
      control = el(MediaControl, {
        label: field.label,
        value: value || 0,
        onChange: function (next) {
          onChange(field.name, next);
        },
      });
    } else if (field.type === "gallery") {
      control = el(GalleryControl, {
        label: field.label,
        value: value || [],
        onChange: function (next) {
          onChange(field.name, next);
        },
      });
    } else if (field.type === "repeater") {
      control = el(RepeaterControl, {
        label: field.label,
        items: value || [],
        fields: field.fields || [],
        onChange: function (next) {
          onChange(field.name, next);
        },
      });
    } else {
      control = el(TextControl, {
        label: field.label,
        value: value || "",
        onChange: function (next) {
          onChange(field.name, next);
        },
      });
    }

    return el("div", { className: "konstanta-field", key: key }, control);
  }

  function BlockEdit(props) {
    var fields = props.fields || [];
    var blockProps = useBlockProps
      ? useBlockProps({ className: "konstanta-block-preview" })
      : { className: "konstanta-block-preview" };

    return el(
      Fragment,
      null,
      el(
        InspectorControls,
        null,
        el(
          PanelBody,
          { title: "Настройки блока", initialOpen: true },
          fields.map(function (field) {
            return renderField(field, props.attributes, function (name, value) {
              var next = {};
              next[name] = value;
              props.setAttributes(next);
            }, field.name);
          })
        )
      ),
      el(
        "div",
        blockProps,
        el("div", { className: "konstanta-block-preview__label" }, props.blockTitle || "Блок «Константа»"),
        el(
          Disabled,
          null,
          ServerSideRender
            ? el(ServerSideRender, {
                block: props.name,
                attributes: props.attributes,
                httpMethod: "POST",
              })
            : el("p", { className: "konstanta-help" }, "Предпросмотр недоступен.")
        )
      )
    );
  }

  if (!ServerSideRender && console && console.warn) {
    console.warn("Konstanta: компонент ServerSideRender не найден.");
  }

  config.blocks.forEach(function (block) {
    wp.blocks.registerBlockType(block.name, {
      title: block.title,
      description: block.description,
      icon: block.icon,
      category: config.category || "konstanta",
      attributes: block.attributes,
      supports: {
        html: false,
        align: false,
        customClassName: false,
      },
      edit: function (props) {
        return el(
          BlockEdit,
          Object.assign({}, props, {
            fields: block.fields,
            blockTitle: block.title,
          })
        );
      },
      save: function () {
        return null;
      },
    });
  });
})();
