<?php
/**
 * Регистрация Gutenberg-блоков темы.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once KONSTANTA_DIR . '/inc/blocks/render.php';

/**
 * Рендер-колбэки блоков.
 *
 * @return array
 */
function konstanta_block_renderers() {
	return array(
		'hero'      => 'konstanta_render_hero',
		'marquee'   => 'konstanta_render_marquee',
		'materials' => 'konstanta_render_materials',
		'steps'     => 'konstanta_render_steps',
		'features'  => 'konstanta_render_features',
		'about'     => 'konstanta_render_about',
		'transport' => 'konstanta_render_transport',
		'gallery'   => 'konstanta_render_gallery',
		'contact'   => 'konstanta_render_contact',
		'faq'       => 'konstanta_render_faq',
		'cta'       => 'konstanta_render_cta',
	);
}

/**
 * Конфигурация блоков.
 *
 * @return array
 */
function konstanta_get_block_definitions() {
	static $definitions = null;

	if ( null !== $definitions ) {
		return $definitions;
	}

	$config    = require KONSTANTA_DIR . '/inc/blocks/config.php';
	$renderers = konstanta_block_renderers();

	foreach ( $config as $slug => $definition ) {
		$config[ $slug ]['render_callback'] = isset( $renderers[ $slug ] ) ? $renderers[ $slug ] : '';
	}

	$definitions = $config;

	return $definitions;
}

/**
 * Значения атрибутов блока по умолчанию.
 *
 * @param string $slug Ярлык блока.
 * @return array
 */
function konstanta_block_defaults( $slug ) {
	$definitions = konstanta_get_block_definitions();
	$defaults    = array();

	if ( empty( $definitions[ $slug ]['attributes'] ) ) {
		return $defaults;
	}

	foreach ( $definitions[ $slug ]['attributes'] as $key => $attribute ) {
		$defaults[ $key ] = isset( $attribute['default'] ) ? $attribute['default'] : '';
	}

	return $defaults;
}

/**
 * Конфигурация для редактора блоков.
 *
 * @return array
 */
function konstanta_get_editor_config() {
	$blocks = array();

	foreach ( konstanta_get_block_definitions() as $slug => $definition ) {
		$blocks[] = array(
			'name'        => 'konstanta/' . $slug,
			'title'       => $definition['title'],
			'description' => $definition['description'],
			'icon'        => $definition['icon'],
			'attributes'  => $definition['attributes'],
			'fields'      => $definition['fields'],
		);
	}

	return array(
		'blocks'   => $blocks,
		'category' => 'konstanta',
	);
}

/**
 * Регистрация блоков.
 */
function konstanta_register_blocks() {
	foreach ( konstanta_get_block_definitions() as $slug => $definition ) {
		register_block_type(
			'konstanta/' . $slug,
			array(
				'api_version'     => 3,
				'title'           => $definition['title'],
				'description'     => $definition['description'],
				'category'        => 'konstanta',
				'icon'            => $definition['icon'],
				'attributes'      => $definition['attributes'],
				'supports'        => array(
					'html'            => false,
					'align'           => false,
					'customClassName' => false,
					'multiple'        => true,
				),
				'render_callback' => $definition['render_callback'],
			)
		);
	}
}
add_action( 'init', 'konstanta_register_blocks', 20 );
