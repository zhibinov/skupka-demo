<?php
/**
 * Обычная страница.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<section class="section page-section">
		<div class="container page-container">
			<article <?php post_class( 'page-content' ); ?>>
				<h1 class="page-title"><?php the_title(); ?></h1>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			</article>
		</div>
	</section>
	<?php
endwhile;

get_footer();
