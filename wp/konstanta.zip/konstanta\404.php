<?php
/**
 * Страница 404.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<section class="section page-section">
	<div class="container page-container">
		<span class="eyebrow">404</span>
		<h1 class="page-title">Страница не найдена</h1>
		<div class="entry-content">
			<p>Возможно, страница была удалена или вы перешли по неверной ссылке.</p>
			<p><a class="btn btn--accent" href="<?php echo esc_url( home_url( '/' ) ); ?>">На главную</a></p>
		</div>
	</div>
</section>
<?php
get_footer();
