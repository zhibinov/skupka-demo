<?php
/**
 * Главная страница.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

if ( have_posts() ) :
	while ( have_posts() ) :
		the_post();
		the_content();
	endwhile;
else :
	?>
	<section class="section">
		<div class="container page-container">
			<h1 class="page-title">Главная страница</h1>
			<p>Содержимое главной страницы ещё не заполнено.</p>
			<?php if ( current_user_can( 'manage_options' ) ) : ?>
				<p><a class="btn btn--accent" href="<?php echo esc_url( admin_url( 'themes.php?page=konstanta-demo' ) ); ?>">Установить демо-контент «Константа»</a></p>
			<?php endif; ?>
		</div>
	</section>
	<?php
endif;

get_footer();
