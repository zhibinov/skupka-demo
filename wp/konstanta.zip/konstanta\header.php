<?php
/**
 * Шапка сайта.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="theme-color" content="#0B0E11">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="icon" href="<?php echo esc_url( KONSTANTA_URI . '/assets/img/favicon.svg' ); ?>" type="image/svg+xml">
	<script>document.documentElement.classList.add('js');</script>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#content">Перейти к содержимому</a>

<header class="site-header" id="header">
	<div class="container header__inner">
		<?php if ( has_custom_logo() ) : ?>
			<div class="logo logo--custom"><?php the_custom_logo(); ?></div>
		<?php else : ?>
			<a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( konstanta_opt( 'brand_name' ) ); ?> — на главную">
				<?php echo konstanta_logo_mark(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="logo__text">
					<strong><?php echo esc_html( konstanta_opt( 'brand_name' ) ); ?></strong>
					<small><?php echo esc_html( konstanta_opt( 'brand_tagline' ) ); ?></small>
				</span>
			</a>
		<?php endif; ?>

		<nav class="nav" id="nav" aria-label="Основная навигация">
			<?php
			konstanta_nav_menu(
				'primary',
				array(
					array( 'Что скупаем', konstanta_section_url( '#materials' ) ),
					array( 'Как работает', konstanta_section_url( '#how' ) ),
					array( 'О компании', konstanta_section_url( '#about' ) ),
					array( 'Контакты', konstanta_section_url( '#contacts' ) ),
				)
			);
			?>
		</nav>

		<div class="header__actions">
			<a class="header__phone" href="<?php echo esc_url( konstanta_phone_href() ); ?>">
				<?php echo konstanta_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span><?php echo esc_html( konstanta_opt( 'phone_display' ) ); ?></span>
			</a>
			<a class="btn btn--accent btn--sm header__cta" href="<?php echo esc_url( konstanta_section_url( '#calc' ) ); ?>">Узнать цену</a>
			<button class="burger" id="burger" type="button" aria-label="Открыть меню" aria-expanded="false" aria-controls="nav">
				<span></span><span></span><span></span>
			</button>
		</div>
	</div>
</header>

<main id="content" class="site-main">
