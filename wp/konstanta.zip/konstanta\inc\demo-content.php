<?php
/**
 * Демо-контент и первичная настройка сайта.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Страница установки демо-контента.
 */
function konstanta_demo_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$done = get_option( 'konstanta_demo_done' );
	?>
	<div class="wrap">
		<h1>Демо-контент «Константа»</h1>
		<p>Установка создаст главную страницу с блоками, 12 материалов, 3 автомобиля, 6 вопросов FAQ, юридические страницы и меню. Изображения будут загружены в медиатеку.</p>
		<p>Повторный запуск не создаёт дубликаты: материалы, транспорт и FAQ ищутся по служебному ключу, изображения — по имени файла.</p>

		<?php if ( isset( $_GET['konstanta_demo'] ) && 'done' === $_GET['konstanta_demo'] ) : ?>
			<div class="notice notice-success is-dismissible"><p>Демо-контент установлен. Проверьте главную страницу и разделы «Материалы», «Транспорт», «FAQ».</p></div>
		<?php endif; ?>

		<?php if ( $done ) : ?>
			<p><strong>Демо-контент уже устанавливался:</strong> <?php echo esc_html( date_i18n( 'd.m.Y H:i', (int) $done ) ); ?>.</p>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'konstanta_import_demo' ); ?>
			<input type="hidden" name="action" value="konstanta_import_demo">
			<p>
				<label>
					<input type="checkbox" name="force" value="1">
					Перезаписать содержимое главной и юридических страниц (если они уже заполнены)
				</label>
			</p>
			<p><button type="submit" class="button button-primary">Установить демо-контент</button></p>
		</form>

		<hr>
		<h2>Что делать после установки</h2>
		<ol>
			<li>Откройте «Настройки → Чтение» и убедитесь, что главная страница — «Главная».</li>
			<li>Проверьте контакты в «Внешний вид → Настроить → Константа».</li>
			<li>Отредактируйте главную страницу в Gutenberg: каждая секция — отдельный блок «Константа».</li>
			<li>Материалы, транспорт и FAQ редактируются в одноимённых разделах админки.</li>
		</ol>
	</div>
	<?php
}
add_action(
	'admin_menu',
	function () {
		add_theme_page(
			'Демо-контент «Константа»',
			'Демо-контент «Константа»',
			'manage_options',
			'konstanta-demo',
			'konstanta_demo_admin_page'
		);
	}
);

/**
 * Обработчик установки демо-контента.
 */
function konstanta_handle_demo_import() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Недостаточно прав.' );
	}

	check_admin_referer( 'konstanta_import_demo' );

	$force = ! empty( $_POST['force'] );
	konstanta_import_demo_content( $force );

	update_option( 'konstanta_demo_done', time() );
	flush_rewrite_rules();

	wp_safe_redirect(
		add_query_arg(
			array(
				'page'            => 'konstanta-demo',
				'konstanta_demo'  => 'done',
			),
			admin_url( 'themes.php' )
		)
	);
	exit;
}
add_action( 'admin_post_konstanta_import_demo', 'konstanta_handle_demo_import' );

/**
 * Уведомление о необходимости установить демо-контент.
 */
function konstanta_demo_admin_notice() {
	if ( get_option( 'konstanta_demo_done' ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$screen = get_current_screen();
	if ( $screen && 'appearance_page_konstanta-demo' === $screen->id ) {
		return;
	}

	echo '<div class="notice notice-info is-dismissible"><p><strong>Тема «Константа» установлена.</strong> Чтобы заполнить сайт содержимым, перейдите в <a href="' . esc_url( admin_url( 'themes.php?page=konstanta-demo' ) ) . '">Внешний вид → Демо-контент «Константа»</a>.</p></div>';
}
add_action( 'admin_notices', 'konstanta_demo_admin_notice' );

/**
 * Импорт изображения из темы в медиатеку.
 *
 * @param string $relative Относительный путь.
 * @param string $title    Заголовок.
 * @param string $alt      Alt.
 * @return int
 */
function konstanta_demo_image( $relative, $title, $alt ) {
	$relative = ltrim( $relative, '/' );
	$existing = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => '_konstanta_demo_file',
			'meta_value'     => $relative,
		)
	);

	if ( $existing ) {
		return (int) $existing[0];
	}

	$source = KONSTANTA_DIR . '/assets/img/' . $relative;
	if ( ! file_exists( $source ) ) {
		return 0;
	}

	$contents = file_get_contents( $source ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( false === $contents ) {
		return 0;
	}

	$filename = sanitize_file_name( basename( $relative ) );
	$upload   = wp_upload_bits( $filename, null, $contents );
	if ( ! empty( $upload['error'] ) ) {
		return 0;
	}

	$filetype = wp_check_filetype( $filename );
	$insert   = wp_insert_attachment(
		array(
			'post_mime_type' => $filetype['type'] ? $filetype['type'] : 'image/jpeg',
			'post_title'     => $title,
			'post_content'   => '',
			'post_status'    => 'inherit',
		),
		$upload['file']
	);

	if ( is_wp_error( $insert ) || ! $insert ) {
		return 0;
	}

	require_once ABSPATH . 'wp-admin/includes/image.php';
	$metadata = wp_generate_attachment_metadata( $insert, $upload['file'] );
	wp_update_attachment_metadata( $insert, $metadata );
	update_post_meta( $insert, '_wp_attachment_image_alt', $alt );
	update_post_meta( $insert, '_konstanta_demo_file', $relative );

	return (int) $insert;
}

/**
 * Юридический текст из файла темы.
 *
 * @param string $file Имя файла.
 * @return string
 */
function konstanta_demo_legal_content( $file ) {
	$path = KONSTANTA_DIR . '/assets/legal/' . $file;
	if ( ! file_exists( $path ) ) {
		return '';
	}

	$content = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	if ( false === $content ) {
		return '';
	}

	return preg_replace_callback(
		'/href="(privacy|consent|offer|index)\.html(#[^"]*)?"/',
		function ( $matches ) {
			$slug   = $matches[1];
			$anchor = isset( $matches[2] ) ? $matches[2] : '';
			if ( 'index' === $slug ) {
				return 'href="' . esc_url( home_url( '/' ) ) . $anchor . '"';
			}
			return 'href="' . esc_url( konstanta_page_url( $slug ) ) . $anchor . '"';
		},
		$content
	);
}

/**
 * Создание страницы, если её нет.
 *
 * @param string $slug     Ярлык.
 * @param string $title    Заголовок.
 * @param string $template Шаблон.
 * @return int
 */
function konstanta_demo_ensure_page( $slug, $title, $template = '' ) {
	$page = get_page_by_path( $slug );
	if ( $page instanceof WP_Post ) {
		$id = (int) $page->ID;
	} else {
		$id = wp_insert_post(
			wp_slash(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => $title,
					'post_name'    => $slug,
					'post_content' => '',
				)
			)
		);
	}

	if ( ! is_wp_error( $id ) && $id ) {
		if ( $template ) {
			update_post_meta( $id, '_wp_page_template', $template );
			update_post_meta( $id, '_konstanta_updated', '02.11.2026' );
		}
	}

	return is_wp_error( $id ) ? 0 : (int) $id;
}

/**
 * Создание/обновление записи демо-контента.
 *
 * @param array  $data  Данные.
 * @param string $key   Служебный ключ.
 * @param bool   $force Перезапись.
 * @return int
 */
function konstanta_demo_ensure_post( $data, $key, $force = false ) {
	$existing = get_posts(
		array(
			'post_type'      => $data['post_type'],
			'post_status'    => 'any',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => '_konstanta_demo_key',
			'meta_value'     => $key,
		)
	);

	if ( $existing && ! $force ) {
		return (int) $existing[0];
	}

	if ( $existing ) {
		$data['ID'] = (int) $existing[0];
		$id         = wp_update_post( wp_slash( $data ) );
	} else {
		$id = wp_insert_post( wp_slash( $data ) );
	}

	if ( is_wp_error( $id ) || ! $id ) {
		return 0;
	}

	update_post_meta( $id, '_konstanta_demo_key', $key );

	return (int) $id;
}

/**
 * Массив блока для serialize_blocks().
 *
 * @param string $name  Имя блока.
 * @param array  $attrs Атрибуты.
 * @return array
 */
function konstanta_demo_block( $name, $attrs = array() ) {
	return array(
		'blockName'    => $name,
		'attrs'        => $attrs,
		'innerBlocks'  => array(),
		'innerContent' => array(),
	);
}

/**
 * Установка демо-контента.
 *
 * @param bool $force Перезаписать содержимое страниц.
 * @return array
 */
function konstanta_import_demo_content( $force = false ) {
	$log = array();

	update_option( 'blogname', konstanta_opt( 'brand_name' ) );
	update_option( 'blogdescription', konstanta_opt( 'brand_tagline' ) );

	$categories = array(
		'cable'    => 'Кабель и провод',
		'valve'    => 'Арматура',
		'electric' => 'Электрика',
		'metal'    => 'Металлопрокат',
	);

	foreach ( $categories as $slug => $name ) {
		if ( ! term_exists( $slug, 'material_category' ) ) {
			wp_insert_term(
				$name,
				'material_category',
				array(
					'slug' => $slug,
				)
			);
		}
	}

	$materials = array(
		array(
			'file'    => 'materials/01_kabel.jpg',
			'title'   => 'Кабель',
			'excerpt' => 'Силовой, контрольный, в изоляции и без, новые остатки и б/у.',
			'cat'     => 'cable',
			'alt'     => 'Кабель',
		),
		array(
			'file'    => 'materials/02_zapornaya_armatura.jpg',
			'title'   => 'Запорная арматура',
			'excerpt' => 'Краны, затворы, фитинги, фланцы — новые и б/у.',
			'cat'     => 'valve',
			'alt'     => 'Запорная арматура',
		),
		array(
			'file'    => 'materials/03_provod.jpg',
			'title'   => 'Провод',
			'excerpt' => 'СИП, сварочный, монтажный, силовой, остатки бухт.',
			'cat'     => 'cable',
			'alt'     => 'Провод',
		),
		array(
			'file'    => 'materials/04_electrika.jpg',
			'title'   => 'Электрика',
			'excerpt' => 'Щиты, автоматы, счётчики, контакторы, розетки.',
			'cat'     => 'electric',
			'alt'     => 'Электрика',
		),
		array(
			'file'    => 'materials/05_zadvizhki.jpg',
			'title'   => 'Задвижки',
			'excerpt' => 'Фланцевые и под приварку, новые и б/у.',
			'cat'     => 'valve',
			'alt'     => 'Задвижки',
		),
		array(
			'file'    => 'materials/06_ventili.jpg',
			'title'   => 'Вентиля',
			'excerpt' => 'Клиновые, дисковые, поворотные, с ручным и электроприводом.',
			'cat'     => 'valve',
			'alt'     => 'Вентиля',
		),
		array(
			'file'    => 'materials/07_klapany.jpg',
			'title'   => 'Клапана',
			'excerpt' => 'Обратные, предохранительные, регулирующие, запорные.',
			'cat'     => 'valve',
			'alt'     => 'Клапана',
		),
		array(
			'file'    => 'materials/08_elektrodvigateli.jpg',
			'title'   => 'Электродвигатели',
			'excerpt' => 'Асинхронные, генераторы, редукторы, мотор-редукторы.',
			'cat'     => 'electric',
			'alt'     => 'Электродвигатели',
		),
		array(
			'file'    => 'materials/09_nasosy.jpg',
			'title'   => 'Насосы',
			'excerpt' => 'Центробежные, погружные, промышленные, с электродвигателем.',
			'cat'     => 'electric',
			'alt'     => 'Насосы',
		),
		array(
			'file'    => 'materials/10_metalloprokat_truba.jpg',
			'title'   => 'Труба',
			'excerpt' => 'Бесшовная, сварная, профильная, любые диаметры и длины.',
			'cat'     => 'metal',
			'alt'     => 'Труба',
		),
		array(
			'file'    => 'materials/11_metalloprokat_shveller.jpg',
			'title'   => 'Швеллер',
			'excerpt' => 'Горячекатаный и гнутый, любые размеры и длины.',
			'cat'     => 'metal',
			'alt'     => 'Швеллер',
		),
		array(
			'file'    => 'materials/12_metalloprokat_ugolok.jpg',
			'title'   => 'Уголок',
			'excerpt' => 'Равнополочный и неравнополочный, любые размеры.',
			'cat'     => 'metal',
			'alt'     => 'Уголок',
		),
	);

	foreach ( $materials as $index => $item ) {
		$key   = 'material-' . ( $index + 1 );
		$image = konstanta_demo_image( $item['file'], $item['title'], $item['alt'] );
		$id    = konstanta_demo_ensure_post(
			array(
				'post_type'    => 'material',
				'post_status'  => 'publish',
				'post_title'   => $item['title'],
				'post_excerpt' => $item['excerpt'],
				'post_content' => '',
				'menu_order'   => $index,
			),
			$key,
			$force
		);

		if ( $id ) {
			if ( $image ) {
				set_post_thumbnail( $id, $image );
			}
			$term = get_term_by( 'slug', $item['cat'], 'material_category' );
			if ( $term ) {
				wp_set_object_terms( $id, array( (int) $term->term_id ), 'material_category' );
			}
		}
		$log[] = 'Материал: ' . $item['title'];
	}

	$vehicles = array(
		array(
			'file'     => 'transport/gazelle.jpg',
			'title'    => 'Автомобиль Газель',
			'excerpt'  => 'Для небольших партий и срочного вывоза.',
			'capacity' => 'до 5 тонн',
			'features' => "Вывоз: бесплатно\nПогрузка: обговаривается\nВыезд в день обращения",
			'alt'      => 'Газель для вывоза продукции',
		),
		array(
			'file'     => 'transport/lomovoz.jpg',
			'title'    => 'Грузовик с манипулятором',
			'excerpt'  => 'Для крупных объектов и тяжёлого оборудования.',
			'capacity' => 'до 12 тонн',
			'features' => "Вывоз: бесплатно\nДлина кузова 6 метров\nПогрузка: обговаривается",
			'alt'      => 'Грузовик с манипулятором',
		),
		array(
			'file'     => 'transport/dlinnomer.jpg',
			'title'    => 'Длинномер',
			'excerpt'  => 'Для труб, швеллера, уголка и больших объёмов.',
			'capacity' => 'до 20 тонн',
			'features' => "Вывоз: бесплатно\nПогрузка: обговаривается\nМежрегиональные перевозки",
			'alt'      => 'Длинномер для металлопроката',
		),
	);

	foreach ( $vehicles as $index => $item ) {
		$key   = 'vehicle-' . ( $index + 1 );
		$image = konstanta_demo_image( $item['file'], $item['title'], $item['alt'] );
		$id    = konstanta_demo_ensure_post(
			array(
				'post_type'    => 'vehicle',
				'post_status'  => 'publish',
				'post_title'   => $item['title'],
				'post_excerpt' => $item['excerpt'],
				'post_content' => '',
				'menu_order'   => $index,
			),
			$key,
			$force
		);

		if ( $id ) {
			if ( $image ) {
				set_post_thumbnail( $id, $image );
			}
			update_post_meta( $id, '_konstanta_vehicle_capacity', $item['capacity'] );
			update_post_meta( $id, '_konstanta_vehicle_features', $item['features'] );
		}
		$log[] = 'Транспорт: ' . $item['title'];
	}

	$faqs = array(
		array(
			'title'   => 'С какими лицами вы сотрудничаете?',
			'content' => 'Мы постоянно сотрудничаем с компаниями и физическими лицами. Для юрлиц предоставляем договор, акт и закрывающие документы, работаем с НДС и без.',
		),
		array(
			'title'   => 'Как быть с демонтажем?',
			'content' => 'У нас имеются специально обученные люди по демонтажу. Оцениваем объект, согласовываем время и выполняем работы с соблюдением техники безопасности.',
		),
		array(
			'title'   => 'Какой транспорт используется при логистике?',
			'content' => 'Газель до 5 тонн, грузовик с манипулятором до 12 тонн, длинномер до 20 тонн. Подберём машину под вашу партию.',
		),
		array(
			'title'   => 'Как быстро я могу получить свои деньги?',
			'content' => 'После приёма товара расчёт происходит сразу на месте, наличными или безналичным способом.',
		),
		array(
			'title'   => 'Работаете ли вы по всей России?',
			'content' => 'Да, работаем по всей России. Для крупных объектов организуем вывоз и демонтаж в любом регионе.',
		),
		array(
			'title'   => 'Какие документы вы предоставляете?',
			'content' => 'Договор, акт приёма-передачи, чеки об оплате. Для бухгалтерии юрлиц — полный комплект закрывающих документов.',
		),
	);

	foreach ( $faqs as $index => $item ) {
		konstanta_demo_ensure_post(
			array(
				'post_type'    => 'faq',
				'post_status'  => 'publish',
				'post_title'   => $item['title'],
				'post_content' => $item['content'],
				'menu_order'   => $index,
			),
			'faq-' . ( $index + 1 ),
			$force
		);
		$log[] = 'FAQ: ' . $item['title'];
	}

	$hero_image = konstanta_demo_image( 'hero.jpg', 'Главный экран', 'Промышленная площадка Константа' );
	$about_image = konstanta_demo_image( 'about.jpg', 'О компании', 'Погрузчик вывозит продукцию с площадки' );

	$gallery_files = array(
		array(
			'file' => 'gallery/7.jpg',
			'alt'  => 'Трансформаторы, выкупленные у предприятия',
		),
		array(
			'file' => 'gallery/01_kabel.jpg',
			'alt'  => 'Кабель на площадке',
		),
		array(
			'file' => 'gallery/02_pogruzka_produkcii.jpg',
			'alt'  => 'Погрузка продукции манипулятором',
		),
		array(
			'file' => 'gallery/03_truby_i_zapornaya_armatura.jpg',
			'alt'  => 'Трубы и запорная арматура',
		),
		array(
			'file' => 'gallery/04_starye_elektrodvigateli.jpg',
			'alt'  => 'Электродвигатели',
		),
		array(
			'file' => 'gallery/05_smeshannaya_produkciya.jpg',
			'alt'  => 'Смешанная продукция',
		),
		array(
			'file' => 'gallery/06_kabel_i_provod.jpg',
			'alt'  => 'Кабель и провод',
		),
	);

	$gallery_ids = array();
	foreach ( $gallery_files as $item ) {
		$image_id = konstanta_demo_image( $item['file'], 'Фото последних скупок', $item['alt'] );
		if ( $image_id ) {
			$gallery_ids[] = $image_id;
		}
	}

	$privacy_id = konstanta_demo_ensure_page( 'privacy', 'Политика конфиденциальности', 'templates/legal.php' );
	$consent_id = konstanta_demo_ensure_page( 'consent', 'Согласие на обработку персональных данных', 'templates/legal.php' );
	$offer_id   = konstanta_demo_ensure_page( 'offer', 'Публичная оферта', 'templates/legal.php' );
	$home_id    = konstanta_demo_ensure_page( 'home', 'Главная' );

	$legal_pages = array(
		$privacy_id => 'legal-privacy.html',
		$consent_id => 'legal-consent.html',
		$offer_id   => 'legal-offer.html',
	);

	foreach ( $legal_pages as $page_id => $file ) {
		$content = konstanta_demo_legal_content( $file );
		if ( ! $page_id || ! $content ) {
			continue;
		}
		$page = get_post( $page_id );
		if ( $page && ( $force || '' === trim( $page->post_content ) ) ) {
			wp_update_post(
				wp_slash(
					array(
						'ID'           => $page_id,
						'post_content' => $content,
					)
				)
			);
		}
	}

	if ( $home_id && function_exists( 'serialize_blocks' ) ) {
		$blocks = array(
			konstanta_demo_block(
				'konstanta/hero',
				array(
					'image' => $hero_image,
				)
			),
			konstanta_demo_block( 'konstanta/marquee' ),
			konstanta_demo_block( 'konstanta/materials' ),
			konstanta_demo_block( 'konstanta/steps' ),
			konstanta_demo_block( 'konstanta/features' ),
			konstanta_demo_block(
				'konstanta/about',
				array(
					'image' => $about_image,
				)
			),
			konstanta_demo_block( 'konstanta/transport' ),
			konstanta_demo_block(
				'konstanta/gallery',
				array(
					'images' => $gallery_ids,
				)
			),
			konstanta_demo_block( 'konstanta/contact' ),
			konstanta_demo_block( 'konstanta/faq' ),
			konstanta_demo_block( 'konstanta/cta' ),
		);

		$content = serialize_blocks( $blocks );
		$page    = get_post( $home_id );
		if ( $page && ( $force || '' === trim( $page->post_content ) ) ) {
			wp_update_post(
				wp_slash(
					array(
						'ID'           => $home_id,
						'post_content' => $content,
					)
				)
			);
			$log[] = 'Главная страница: блоки установлены';
		}
	}

	if ( $home_id ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home_id );
	}

	$menu_name = 'Основное меню';
	$menu      = wp_get_nav_menu_object( $menu_name );
	$menu_id   = $menu ? (int) $menu->term_id : (int) wp_create_nav_menu( $menu_name );

	if ( $menu_id ) {
		$items = wp_get_nav_menu_items( $menu_id );
		if ( ! $items ) {
			$links = array(
				'Что скупаем' => home_url( '/#materials' ),
				'Как работает' => home_url( '/#how' ),
				'О компании'  => home_url( '/#about' ),
				'Наши работы' => home_url( '/#gallery' ),
				'Контакты'    => home_url( '/#contacts' ),
			);
			foreach ( $links as $title => $url ) {
				wp_update_nav_menu_item(
					$menu_id,
					0,
					array(
						'menu-item-title'  => $title,
						'menu-item-url'    => $url,
						'menu-item-status' => 'publish',
					)
				);
			}
		}

		$locations            = get_theme_mod( 'nav_menu_locations', array() );
		$locations['primary'] = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );
	}

	$log[] = 'Страницы, меню и изображения обработаны';

	return $log;
}
