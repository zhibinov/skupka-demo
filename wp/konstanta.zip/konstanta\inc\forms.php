<?php
/**
 * Обработка формы заявки.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ответ на заявку.
 *
 * @param bool   $success Успех.
 * @param string $message Сообщение.
 * @param array  $extra   Дополнительные данные.
 */
function konstanta_request_response( $success, $message, $extra = array() ) {
	if ( wp_doing_ajax() ) {
		$data = array_merge( array( 'message' => $message ), $extra );
		if ( $success ) {
			wp_send_json_success( $data );
		}
		wp_send_json_error( $data );
	}

	$url = wp_get_referer();
	if ( ! $url ) {
		$url = home_url( '/' );
	}
	$url = add_query_arg( 'sent', $success ? '1' : 'error', $url ) . '#calc';
	wp_safe_redirect( $url );
	exit;
}

/**
 * Нормализация массива файлов.
 *
 * @param array $files $_FILES.
 * @return array
 */
function konstanta_normalize_files( $files ) {
	if ( empty( $files['name'] ) ) {
		return array();
	}

	$normalized = array();

	if ( ! is_array( $files['name'] ) ) {
		return array(
			array(
				'name'     => $files['name'],
				'type'     => $files['type'],
				'tmp_name' => $files['tmp_name'],
				'error'    => $files['error'],
				'size'     => $files['size'],
			),
		);
	}

	foreach ( $files['name'] as $index => $name ) {
		$normalized[] = array(
			'name'     => $name,
			'type'     => isset( $files['type'][ $index ] ) ? $files['type'][ $index ] : '',
			'tmp_name' => isset( $files['tmp_name'][ $index ] ) ? $files['tmp_name'][ $index ] : '',
			'error'    => isset( $files['error'][ $index ] ) ? $files['error'][ $index ] : UPLOAD_ERR_NO_FILE,
			'size'     => isset( $files['size'][ $index ] ) ? $files['size'][ $index ] : 0,
		);
	}

	return $normalized;
}

/**
 * Загрузка приложенных файлов.
 *
 * @return array [files, attachments, errors]
 */
function konstanta_handle_request_files() {
	if ( empty( $_FILES['files'] ) ) {
		return array( array(), array(), array() );
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';

	$files       = konstanta_normalize_files( $_FILES['files'] );
	$allowed     = array( 'jpg', 'jpeg', 'png', 'webp', 'pdf' );
	$max_size    = 10 * 1024 * 1024;
	$stored      = array();
	$attachments = array();
	$errors      = array();

	if ( count( $files ) > 10 ) {
		return array( array(), array(), array( 'Можно прикрепить не больше 10 файлов.' ) );
	}

	foreach ( $files as $file ) {
		if ( UPLOAD_ERR_NO_FILE === (int) $file['error'] ) {
			continue;
		}

		if ( UPLOAD_ERR_OK !== (int) $file['error'] ) {
			$errors[] = 'Не удалось загрузить файл «' . sanitize_file_name( $file['name'] ) . '».';
			continue;
		}

		if ( (int) $file['size'] > $max_size ) {
			$errors[] = 'Файл «' . sanitize_file_name( $file['name'] ) . '» больше 10 МБ.';
			continue;
		}

		$extension = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		if ( ! in_array( $extension, $allowed, true ) ) {
			$errors[] = 'Файл «' . sanitize_file_name( $file['name'] ) . '» имеет недопустимый формат.';
			continue;
		}
	}

	if ( $errors ) {
		return array( array(), array(), $errors );
	}

	foreach ( $files as $file ) {
		if ( UPLOAD_ERR_NO_FILE === (int) $file['error'] ) {
			continue;
		}

		$upload = wp_handle_upload(
			$file,
			array(
				'test_form' => false,
			)
		);

		if ( ! empty( $upload['error'] ) ) {
			$errors[] = 'Не удалось загрузить файл «' . sanitize_file_name( $file['name'] ) . '».';
			continue;
		}

		$stored[] = array(
			'name' => sanitize_file_name( $file['name'] ),
			'url'  => $upload['url'],
			'path' => $upload['file'],
		);

		$attachments[] = $upload['file'];
	}

	return array( $stored, $attachments, $errors );
}

/**
 * Обработка заявки.
 */
function konstanta_handle_request() {
	$nonce = isset( $_POST['konstanta_nonce'] ) && is_string( $_POST['konstanta_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['konstanta_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'konstanta_request' ) ) {
		konstanta_request_response( false, 'Сессия устарела. Обновите страницу и попробуйте ещё раз.' );
	}

	$honeypot = isset( $_POST['website'] ) && is_string( $_POST['website'] ) ? sanitize_text_field( wp_unslash( $_POST['website'] ) ) : '';
	if ( '' !== $honeypot ) {
		konstanta_request_response( true, 'Заявка отправлена.' );
	}

	$name     = isset( $_POST['name'] ) && is_string( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$phone    = isset( $_POST['phone'] ) && is_string( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$category = isset( $_POST['category'] ) && is_string( $_POST['category'] ) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : '';
	$weight   = isset( $_POST['weight'] ) && is_string( $_POST['weight'] ) ? sanitize_text_field( wp_unslash( $_POST['weight'] ) ) : '';
	$comment  = isset( $_POST['comment'] ) && is_string( $_POST['comment'] ) ? sanitize_textarea_field( wp_unslash( $_POST['comment'] ) ) : '';
	$consent  = ! empty( $_POST['consent'] );

	if ( '' === $name ) {
		konstanta_request_response( false, 'Укажите имя.' );
	}

	if ( strlen( preg_replace( '/\D+/', '', $phone ) ) < 11 ) {
		konstanta_request_response( false, 'Укажите корректный номер телефона.' );
	}

	if ( ! $consent ) {
		konstanta_request_response( false, 'Подтвердите согласие на обработку персональных данных.' );
	}

	list( $stored_files, $attachments, $file_errors ) = konstanta_handle_request_files();
	if ( $file_errors ) {
		konstanta_request_response( false, implode( ' ', $file_errors ) );
	}

	$to = konstanta_opt( 'email' );
	if ( ! is_email( $to ) ) {
		$to = get_option( 'admin_email' );
	}

	$subject = 'Заявка с сайта ' . konstanta_opt( 'brand_name' ) . ' — ' . $name;

	$lines = array(
		'Новая заявка с сайта ' . konstanta_opt( 'brand_name' ),
		'',
		'Имя: ' . $name,
		'Телефон: ' . $phone,
		'Категория: ' . $category,
		'Объём: ' . $weight,
		'Комментарий: ' . $comment,
		'',
		'Страница: ' . ( isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : home_url( '/' ) ),
		'IP: ' . ( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' ),
	);

	if ( $stored_files ) {
		$lines[] = '';
		$lines[] = 'Файлы:';
		foreach ( $stored_files as $file ) {
			$lines[] = '- ' . $file['name'] . ': ' . $file['url'];
		}
	}

	$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
	$sent    = wp_mail( $to, $subject, implode( "\n", $lines ), $headers, $attachments );

	$request_id = wp_insert_post(
		array(
			'post_type'    => 'request',
			'post_status'  => 'private',
			'post_title'   => 'Заявка: ' . $name . ' — ' . date_i18n( 'd.m.Y H:i' ),
			'post_content' => implode( "\n", $lines ),
		),
		true
	);

	if ( is_wp_error( $request_id ) ) {
		$request_id = 0;
	}

	if ( $request_id ) {
		update_post_meta(
			$request_id,
			'_konstanta_request_data',
			array(
				'name'     => $name,
				'phone'    => $phone,
				'category' => $category,
				'weight'   => $weight,
				'comment'  => $comment,
				'files'    => $stored_files,
				'page'     => isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '',
				'ip'       => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '',
				'mail'     => $sent ? 'sent' : 'failed',
			)
		);
	}

	if ( ! $sent ) {
		error_log( 'Konstanta: wp_mail не отправил заявку #' . $request_id ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
	}

	konstanta_request_response(
		true,
		'Заявка отправлена. Мы свяжемся с вами в ближайшее время.',
		array(
			'request_id' => $request_id,
		)
	);
}
add_action( 'admin_post_nopriv_konstanta_request', 'konstanta_handle_request' );
add_action( 'admin_post_konstanta_request', 'konstanta_handle_request' );
add_action( 'wp_ajax_nopriv_konstanta_request', 'konstanta_handle_request' );
add_action( 'wp_ajax_konstanta_request', 'konstanta_handle_request' );
