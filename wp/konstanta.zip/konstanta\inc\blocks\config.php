<?php
/**
 * Конфигурация блоков темы.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$konstanta_icon_options = array(
	array(
		'label' => 'Загрузка',
		'value' => 'upload',
	),
	array(
		'label' => 'Поиск',
		'value' => 'search',
	),
	array(
		'label' => 'Грузовик',
		'value' => 'truck',
	),
	array(
		'label' => 'Кошелёк',
		'value' => 'wallet',
	),
	array(
		'label' => 'Часы',
		'value' => 'clock',
	),
	array(
		'label' => 'Щит',
		'value' => 'shield',
	),
	array(
		'label' => 'Пользователи',
		'value' => 'users',
	),
	array(
		'label' => 'Весы',
		'value' => 'scale',
	),
	array(
		'label' => 'Документ',
		'value' => 'doc',
	),
	array(
		'label' => 'Коробка',
		'value' => 'box',
	),
);

return array(
	'hero'      => array(
		'title'       => 'Hero — первый экран',
		'description' => 'Главный экран с заголовком, кнопками, преимуществами и показателями.',
		'icon'        => 'cover-image',
		'attributes'  => array(
			'eyebrow'       => array(
				'type'    => 'string',
				'default' => 'Вся Россия · 24/7',
			),
			'title_before'  => array(
				'type'    => 'string',
				'default' => 'Вывоз и приём',
			),
			'title_accent'  => array(
				'type'    => 'string',
				'default' => 'кабеля',
			),
			'title_after'   => array(
				'type'    => 'string',
				'default' => ', провода и оборудования',
			),
			'lead'          => array(
				'type'    => 'string',
				'default' => 'Быстрая оценка и расчёт объёма для частных лиц и предприятий. Или вышлите фото нам в удобный мессенджер. Константа — промышленная скупка.',
			),
			'primary_text'  => array(
				'type'    => 'string',
				'default' => 'Узнать цену',
			),
			'primary_url'   => array(
				'type'    => 'string',
				'default' => '#calc',
			),
			'secondary_text' => array(
				'type'    => 'string',
				'default' => 'Написать в Telegram',
			),
			'secondary_url' => array(
				'type'    => 'string',
				'default' => '',
			),
			'trust'         => array(
				'type'    => 'array',
				'default' => array(
					array( 'text' => 'Вывозим бесплатно от 300 кг' ),
					array( 'text' => 'Бесплатный демонтаж' ),
					array( 'text' => 'Честные весы' ),
					array( 'text' => 'Выгодные условия' ),
				),
			),
			'stats'         => array(
				'type'    => 'array',
				'default' => array(
					array(
						'value' => '20 лет',
						'label' => 'на рынке',
					),
					array(
						'value' => '650+',
						'label' => 'постоянных клиентов',
					),
					array(
						'value' => '453 т',
						'label' => 'перерабатываем в месяц',
					),
					array(
						'value' => '>12 ч',
						'label' => 'обработка заказа',
					),
				),
			),
			'image'         => array(
				'type'    => 'integer',
				'default' => 0,
			),
		),
		'fields'      => array(
			array(
				'name'  => 'eyebrow',
				'label' => 'Надзаголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'title_before',
				'label' => 'Заголовок — начало',
				'type'  => 'text',
			),
			array(
				'name'  => 'title_accent',
				'label' => 'Заголовок — акцентное слово',
				'type'  => 'text',
			),
			array(
				'name'  => 'title_after',
				'label' => 'Заголовок — окончание',
				'type'  => 'text',
			),
			array(
				'name'  => 'lead',
				'label' => 'Описание',
				'type'  => 'textarea',
			),
			array(
				'name'  => 'primary_text',
				'label' => 'Главная кнопка',
				'type'  => 'text',
			),
			array(
				'name'  => 'primary_url',
				'label' => 'Ссылка главной кнопки',
				'type'  => 'text',
			),
			array(
				'name'  => 'secondary_text',
				'label' => 'Вторая кнопка',
				'type'  => 'text',
			),
			array(
				'name'  => 'secondary_url',
				'label' => 'Ссылка второй кнопки (пусто — Telegram)',
				'type'  => 'text',
			),
			array(
				'name'   => 'trust',
				'label'  => 'Преимущества на экране',
				'type'   => 'repeater',
				'fields' => array(
					array(
						'name'  => 'text',
						'label' => 'Текст',
						'type'  => 'text',
					),
				),
			),
			array(
				'name'   => 'stats',
				'label'  => 'Показатели',
				'type'   => 'repeater',
				'fields' => array(
					array(
						'name'  => 'value',
						'label' => 'Значение',
						'type'  => 'text',
					),
					array(
						'name'  => 'label',
						'label' => 'Подпись',
						'type'  => 'text',
					),
				),
			),
			array(
				'name'  => 'image',
				'label' => 'Фоновое изображение',
				'type'  => 'media',
			),
		),
	),
	'marquee'   => array(
		'title'       => 'Бегущая строка',
		'description' => 'Полоса с перечнем категорий продукции.',
		'icon'        => 'editor-justify',
		'attributes'  => array(
			'items' => array(
				'type'    => 'array',
				'default' => array(
					array( 'text' => 'Кабель' ),
					array( 'text' => 'Провод' ),
					array( 'text' => 'Запорная арматура' ),
					array( 'text' => 'Задвижки' ),
					array( 'text' => 'Вентиля' ),
					array( 'text' => 'Клапана' ),
					array( 'text' => 'Электрика' ),
					array( 'text' => 'Электродвигатели' ),
					array( 'text' => 'Насосы' ),
					array( 'text' => 'Труба' ),
					array( 'text' => 'Швеллер' ),
					array( 'text' => 'Уголок' ),
				),
			),
		),
		'fields'      => array(
			array(
				'name'   => 'items',
				'label'  => 'Пункты строки',
				'type'   => 'repeater',
				'fields' => array(
					array(
						'name'  => 'text',
						'label' => 'Текст',
						'type'  => 'text',
					),
				),
			),
		),
	),
	'materials' => array(
		'title'       => 'Что скупаем — материалы',
		'description' => 'Сетка материалов из раздела «Материалы» с фильтрами по категориям.',
		'icon'        => 'grid-view',
		'attributes'  => array(
			'eyebrow'     => array(
				'type'    => 'string',
				'default' => 'Что мы скупаем',
			),
			'title'       => array(
				'type'    => 'string',
				'default' => 'Приём кабеля, провода и промышленного оборудования',
			),
			'description' => array(
				'type'    => 'string',
				'default' => 'Константа ведёт приём, вывоз и демонтаж промышленной продукции разных видов. 12 категорий — от кабеля и арматуры до металлопроката. Оцениваем состояние, объём и комплектность.',
			),
			'show_filters' => array(
				'type'    => 'boolean',
				'default' => true,
			),
			'note'        => array(
				'type'    => 'string',
				'default' => 'Не нашли свою позицию? Напишите нам — оценим индивидуально.',
			),
		),
		'fields'      => array(
			array(
				'name'  => 'eyebrow',
				'label' => 'Надзаголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'title',
				'label' => 'Заголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'description',
				'label' => 'Описание',
				'type'  => 'textarea',
			),
			array(
				'name'  => 'show_filters',
				'label' => 'Показывать фильтры',
				'type'  => 'toggle',
			),
			array(
				'name'  => 'note',
				'label' => 'Примечание под сеткой',
				'type'  => 'text',
			),
		),
	),
	'steps'     => array(
		'title'       => 'Этапы работы',
		'description' => 'Четыре шага с иконками.',
		'icon'        => 'list-view',
		'attributes'  => array(
			'eyebrow'     => array(
				'type'    => 'string',
				'default' => 'Как это работает',
			),
			'title'       => array(
				'type'    => 'string',
				'default' => 'Четыре шага до денег на руках',
			),
			'description' => array(
				'type'    => 'string',
				'default' => 'Без посредников и лишних звонков. Оцениваем быстро, вывозим бесплатно, платим сразу.',
			),
			'items'       => array(
				'type'    => 'array',
				'default' => array(
					array(
						'icon'  => 'upload',
						'title' => 'Пришлите фото',
						'text'  => 'В Telegram, MAX или через форму. Достаточно пары кадров и примерного объёма.',
					),
					array(
						'icon'  => 'search',
						'title' => 'Оценим за 5 минут',
						'text'  => 'Назовём цену, объём и предложим удобное время вывоза.',
					),
					array(
						'icon'  => 'truck',
						'title' => 'Приедем и взвесим',
						'text'  => 'Бесплатный вывоз от 300 кг. Погрузку и демонтаж берём на себя.',
					),
					array(
						'icon'  => 'wallet',
						'title' => 'Получите деньги',
						'text'  => 'Наличными или на карту сразу на месте. Для юрлиц — полный пакет документов.',
					),
				),
			),
		),
		'fields'      => array(
			array(
				'name'  => 'eyebrow',
				'label' => 'Надзаголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'title',
				'label' => 'Заголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'description',
				'label' => 'Описание',
				'type'  => 'textarea',
			),
			array(
				'name'   => 'items',
				'label'  => 'Шаги',
				'type'   => 'repeater',
				'fields' => array(
					array(
						'name'    => 'icon',
						'label'   => 'Иконка',
						'type'    => 'select',
						'options' => $konstanta_icon_options,
					),
					array(
						'name'  => 'title',
						'label' => 'Заголовок',
						'type'  => 'text',
					),
					array(
						'name'  => 'text',
						'label' => 'Текст',
						'type'  => 'textarea',
					),
				),
			),
		),
	),
	'features'  => array(
		'title'       => 'Преимущества',
		'description' => 'Сетка преимуществ компании.',
		'icon'        => 'star-filled',
		'attributes'  => array(
			'eyebrow'     => array(
				'type'    => 'string',
				'default' => 'Почему мы',
			),
			'title'       => array(
				'type'    => 'string',
				'default' => 'Почему именно мы?',
			),
			'description' => array(
				'type'    => 'string',
				'default' => 'Мы за долгосрочное сотрудничество, поэтому предлагаем выгодные условия. Вывозим от 300 кг.',
			),
			'items'       => array(
				'type'    => 'array',
				'default' => array(
					array(
						'icon'  => 'truck',
						'title' => 'Бесплатный вывоз',
						'text'  => 'От 300 кг. Своя техника, грузчики и манипулятор.',
					),
					array(
						'icon'  => 'scale',
						'title' => 'Честные весы',
						'text'  => 'Прозрачный расчёт на месте. Показываем вес и итоговый расчёт до оплаты.',
					),
					array(
						'icon'  => 'clock',
						'title' => '24/7 без выходных',
						'text'  => 'Принимаем заявки круглосуточно. Выезд — в течение нескольких часов.',
					),
					array(
						'icon'  => 'shield',
						'title' => 'Документы и гарантии',
						'text'  => 'Договор, акт, чеки. Работаем с НДС и без, с юрлицами и физлицами.',
					),
					array(
						'icon'  => 'wallet',
						'title' => 'Деньги сразу',
						'text'  => 'Наличные, карта. Не нужно ждать денег несколько дней.',
					),
					array(
						'icon'  => 'users',
						'title' => 'Любые объёмы',
						'text'  => 'Бюджет не ограничен, работаем с любым объёмом по всей России.',
					),
				),
			),
		),
		'fields'      => array(
			array(
				'name'  => 'eyebrow',
				'label' => 'Надзаголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'title',
				'label' => 'Заголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'description',
				'label' => 'Описание',
				'type'  => 'textarea',
			),
			array(
				'name'   => 'items',
				'label'  => 'Преимущества',
				'type'   => 'repeater',
				'fields' => array(
					array(
						'name'    => 'icon',
						'label'   => 'Иконка',
						'type'    => 'select',
						'options' => $konstanta_icon_options,
					),
					array(
						'name'  => 'title',
						'label' => 'Заголовок',
						'type'  => 'text',
					),
					array(
						'name'  => 'text',
						'label' => 'Текст',
						'type'  => 'textarea',
					),
				),
			),
		),
	),
	'about'     => array(
		'title'       => 'О компании',
		'description' => 'Блок с фотографией, текстом, списком и кнопкой.',
		'icon'        => 'admin-home',
		'attributes'  => array(
			'eyebrow'     => array(
				'type'    => 'string',
				'default' => 'О компании',
			),
			'title'       => array(
				'type'    => 'string',
				'default' => 'Константа — вывоз и приём промышленных материалов',
			),
			'text1'       => array(
				'type'    => 'string',
				'default' => 'Основное направление деятельности компании «Константа» — вывоз и приём кабеля, провода, металлопроката, запорной арматуры, электрики и промышленного оборудования. Цель нашей работы — обеспечить максимальное удобство нашим клиентам, быстро и качественно выполнить демонтаж и вывоз продукции с соблюдением всех требований заказчика и норм техники безопасности.',
			),
			'text2'       => array(
				'type'    => 'string',
				'default' => 'Предоставляем все необходимые документы. Для оптовых клиентов имеются особо выгодные индивидуальные предложения.',
			),
			'list'        => array(
				'type'    => 'array',
				'default' => array(
					array( 'text' => 'Собственная техника и грузчики' ),
					array( 'text' => 'Демонтаж и вывоз под ключ' ),
					array( 'text' => 'Прозрачный расчёт на месте' ),
				),
			),
			'button_text' => array(
				'type'    => 'string',
				'default' => 'Получить консультацию',
			),
			'button_url'  => array(
				'type'    => 'string',
				'default' => '#calc',
			),
			'image'       => array(
				'type'    => 'integer',
				'default' => 0,
			),
			'badge_value' => array(
				'type'    => 'string',
				'default' => 'с 2005',
			),
			'badge_label' => array(
				'type'    => 'string',
				'default' => 'года на рынке',
			),
		),
		'fields'      => array(
			array(
				'name'  => 'eyebrow',
				'label' => 'Надзаголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'title',
				'label' => 'Заголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'text1',
				'label' => 'Первый абзац',
				'type'  => 'textarea',
			),
			array(
				'name'  => 'text2',
				'label' => 'Второй абзац',
				'type'  => 'textarea',
			),
			array(
				'name'   => 'list',
				'label'  => 'Список преимуществ',
				'type'   => 'repeater',
				'fields' => array(
					array(
						'name'  => 'text',
						'label' => 'Текст',
						'type'  => 'text',
					),
				),
			),
			array(
				'name'  => 'button_text',
				'label' => 'Текст кнопки',
				'type'  => 'text',
			),
			array(
				'name'  => 'button_url',
				'label' => 'Ссылка кнопки',
				'type'  => 'text',
			),
			array(
				'name'  => 'image',
				'label' => 'Фотография',
				'type'  => 'media',
			),
			array(
				'name'  => 'badge_value',
				'label' => 'Бейдж — значение',
				'type'  => 'text',
			),
			array(
				'name'  => 'badge_label',
				'label' => 'Бейдж — подпись',
				'type'  => 'text',
			),
		),
	),
	'transport' => array(
		'title'       => 'Логистика — транспорт',
		'description' => 'Карточки автомобилей из раздела «Транспорт».',
		'icon'        => 'car',
		'attributes'  => array(
			'eyebrow'     => array(
				'type'    => 'string',
				'default' => 'Логистика',
			),
			'title'       => array(
				'type'    => 'string',
				'default' => 'Закажите автомобиль на любой объём вашей продукции',
			),
			'description' => array(
				'type'    => 'string',
				'default' => 'Вывезем кабель, провод или оборудование своим транспортом. Погрузку и демонтаж обсудим заранее.',
			),
		),
		'fields'      => array(
			array(
				'name'  => 'eyebrow',
				'label' => 'Надзаголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'title',
				'label' => 'Заголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'description',
				'label' => 'Описание',
				'type'  => 'textarea',
			),
		),
	),
	'gallery'   => array(
		'title'       => 'Наши работы — галерея',
		'description' => 'Слайдер фотографий с лайтбоксом. Фото выбираются из медиатеки.',
		'icon'        => 'format-gallery',
		'attributes'  => array(
			'eyebrow'     => array(
				'type'    => 'string',
				'default' => 'Наши работы',
			),
			'title'       => array(
				'type'    => 'string',
				'default' => 'Фото последних скупок',
			),
			'description' => array(
				'type'    => 'string',
				'default' => 'Кабель, провод, оборудование и арматура — реальные партии, которые мы уже вывезли.',
			),
			'images'      => array(
				'type'    => 'array',
				'default' => array(),
			),
		),
		'fields'      => array(
			array(
				'name'  => 'eyebrow',
				'label' => 'Надзаголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'title',
				'label' => 'Заголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'description',
				'label' => 'Описание',
				'type'  => 'textarea',
			),
			array(
				'name'  => 'images',
				'label' => 'Фотографии',
				'type'  => 'gallery',
			),
		),
	),
	'contact'   => array(
		'title'       => 'Расчёт стоимости и форма',
		'description' => 'Контакты и форма заявки с загрузкой фото.',
		'icon'        => 'email-alt',
		'attributes'  => array(
			'eyebrow'     => array(
				'type'    => 'string',
				'default' => 'Расчёт стоимости',
			),
			'title'       => array(
				'type'    => 'string',
				'default' => 'Рассчитаем стоимость',
			),
			'description' => array(
				'type'    => 'string',
				'default' => 'Оставьте заявку на расчёт стоимости, и вы убедитесь, что мы покупаем материалы на выгодных условиях.',
			),
			'form_note'   => array(
				'type'    => 'string',
				'default' => 'Ответим в течение 5 минут в рабочее время.',
			),
		),
		'fields'      => array(
			array(
				'name'  => 'eyebrow',
				'label' => 'Надзаголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'title',
				'label' => 'Заголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'description',
				'label' => 'Описание',
				'type'  => 'textarea',
			),
			array(
				'name'  => 'form_note',
				'label' => 'Примечание под формой',
				'type'  => 'text',
			),
		),
	),
	'faq'       => array(
		'title'       => 'FAQ — частые вопросы',
		'description' => 'Список вопросов из раздела «FAQ».',
		'icon'        => 'editor-help',
		'attributes'  => array(
			'eyebrow'     => array(
				'type'    => 'string',
				'default' => 'FAQ',
			),
			'title'       => array(
				'type'    => 'string',
				'default' => 'Частые вопросы',
			),
			'description' => array(
				'type'    => 'string',
				'default' => 'Не нашли ответ? Напишите в Telegram — ответим быстро.',
			),
			'button_text' => array(
				'type'    => 'string',
				'default' => 'Задать вопрос',
			),
			'button_url'  => array(
				'type'    => 'string',
				'default' => '',
			),
		),
		'fields'      => array(
			array(
				'name'  => 'eyebrow',
				'label' => 'Надзаголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'title',
				'label' => 'Заголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'description',
				'label' => 'Описание',
				'type'  => 'textarea',
			),
			array(
				'name'  => 'button_text',
				'label' => 'Текст кнопки',
				'type'  => 'text',
			),
			array(
				'name'  => 'button_url',
				'label' => 'Ссылка кнопки (пусто — Telegram)',
				'type'  => 'text',
			),
		),
	),
	'cta'       => array(
		'title'       => 'Финальный призыв к действию',
		'description' => 'Тёмный блок с кнопками связи.',
		'icon'        => 'megaphone',
		'attributes'  => array(
			'eyebrow'     => array(
				'type'    => 'string',
				'default' => 'Скупка 24/7',
			),
			'title'       => array(
				'type'    => 'string',
				'default' => 'Сдайте продукцию по самым выгодным условиям',
			),
			'description' => array(
				'type'    => 'string',
				'default' => 'Оставьте заявку, и мы свяжемся с вами в ближайшее время для уточнения информации. Бесплатный вывоз от 300 кг.',
			),
			'primary_text' => array(
				'type'    => 'string',
				'default' => 'Оставить заявку',
			),
			'primary_url'  => array(
				'type'    => 'string',
				'default' => '#calc',
			),
		),
		'fields'      => array(
			array(
				'name'  => 'eyebrow',
				'label' => 'Надзаголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'title',
				'label' => 'Заголовок',
				'type'  => 'text',
			),
			array(
				'name'  => 'description',
				'label' => 'Описание',
				'type'  => 'textarea',
			),
			array(
				'name'  => 'primary_text',
				'label' => 'Текст главной кнопки',
				'type'  => 'text',
			),
			array(
				'name'  => 'primary_url',
				'label' => 'Ссылка главной кнопки',
				'type'  => 'text',
			),
		),
	),
);
