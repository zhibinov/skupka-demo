<?php
/**
 * Template Name: Юридический документ
 * Description: Страница политики, согласия или оферты.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();
	$updated = get_post_meta( get_the_ID(), '_konstanta_updated', true );
	if ( ! $updated ) {
		$updated = '02.11.2026';
	}
	?>
	<div class="legal-main">
		<div class="container legal-container">
			<a class="legal-back" href="<?php echo esc_url( home_url( '/' ) ); ?>">← На главную</a>
			<span class="eyebrow">Документы</span>
			<h1><?php the_title(); ?></h1>
			<p class="legal-updated">Редакция от <?php echo esc_html( $updated ); ?></p>

			<div class="legal-content">
				<?php the_content(); ?>
			</div>
		</div>
	</div>
	<?php
endwhile;

get_footer();
