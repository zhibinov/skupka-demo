<?php
/**
 * Настройки темы в Customizer.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Регистрация настроек.
 *
 * @param WP_Customize_Manager $wp_customize Менеджер.
 */
function konstanta_customize_register( $wp_customize ) {
	$defaults = konstanta_defaults();

	$wp_customize->add_panel(
		'konstanta_panel',
		array(
			'title'       => 'Константа',
			'description' => 'Контакты, бренд и реквизиты для шапки, подвала и форм.',
			'priority'    => 20,
		)
	);

	$sections = array(
		'konstanta_brand'    => array(
			'title' => 'Бренд',
			'desc'  => 'Название и подпись под логотипом.',
		),
		'konstanta_contacts' => array(
			'title' => 'Контакты',
			'desc'  => 'Телефон, мессенджеры, email и адрес.',
		),
		'konstanta_legal'    => array(
			'title' => 'Реквизиты и подвал',
			'desc'  => 'Юридические данные и подпись разработчика.',
		),
	);

	foreach ( $sections as $id => $section ) {
		$wp_customize->add_section(
			$id,
			array(
				'title'       => $section['title'],
				'description' => $section['desc'],
				'panel'       => 'konstanta_panel',
			)
		);
	}

	$fields = array(
		'brand_name'    => array(
			'section' => 'konstanta_brand',
			'label'   => 'Название бренда',
			'type'    => 'text',
		),
		'brand_tagline' => array(
			'section' => 'konstanta_brand',
			'label'   => 'Подпись под названием',
			'type'    => 'text',
		),
		'phone_display' => array(
			'section' => 'konstanta_contacts',
			'label'   => 'Телефон (как показывать)',
			'type'    => 'text',
		),
		'phone_link'    => array(
			'section' => 'konstanta_contacts',
			'label'   => 'Телефон для ссылки',
			'type'    => 'text',
		),
		'telegram_url'  => array(
			'section' => 'konstanta_contacts',
			'label'   => 'Ссылка Telegram',
			'type'    => 'url',
		),
		'max_url'       => array(
			'section' => 'konstanta_contacts',
			'label'   => 'Ссылка MAX',
			'type'    => 'url',
		),
		'email'         => array(
			'section' => 'konstanta_contacts',
			'label'   => 'Email для заявок',
			'type'    => 'email',
		),
		'address'       => array(
			'section' => 'konstanta_contacts',
			'label'   => 'Адрес',
			'type'    => 'text',
		),
		'address_url'   => array(
			'section' => 'konstanta_contacts',
			'label'   => 'Ссылка на карту',
			'type'    => 'url',
		),
		'hours'         => array(
			'section' => 'konstanta_contacts',
			'label'   => 'Режим работы',
			'type'    => 'text',
		),
		'legal_name'    => array(
			'section' => 'konstanta_legal',
			'label'   => 'Юридическое лицо',
			'type'    => 'text',
		),
		'inn'           => array(
			'section' => 'konstanta_legal',
			'label'   => 'ИНН',
			'type'    => 'text',
		),
		'ogrn'          => array(
			'section' => 'konstanta_legal',
			'label'   => 'ОГРН',
			'type'    => 'text',
		),
		'offer_note'    => array(
			'section' => 'konstanta_legal',
			'label'   => 'Примечание в подвале',
			'type'    => 'textarea',
		),
		'footer_text'   => array(
			'section' => 'konstanta_legal',
			'label'   => 'Текст о компании в подвале',
			'type'    => 'textarea',
		),
		'dev_text'      => array(
			'section' => 'konstanta_legal',
			'label'   => 'Подпись разработчика',
			'type'    => 'text',
		),
		'dev_url'       => array(
			'section' => 'konstanta_legal',
			'label'   => 'Ссылка разработчика',
			'type'    => 'url',
		),
	);

	foreach ( $fields as $key => $field ) {
		$sanitize = 'sanitize_text_field';
		if ( 'url' === $field['type'] ) {
			$sanitize = 'esc_url_raw';
		} elseif ( 'email' === $field['type'] ) {
			$sanitize = 'sanitize_email';
		} elseif ( 'textarea' === $field['type'] ) {
			$sanitize = 'sanitize_textarea_field';
		}

		$wp_customize->add_setting(
			$key,
			array(
				'default'           => isset( $defaults[ $key ] ) ? $defaults[ $key ] : '',
				'sanitize_callback' => $sanitize,
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			$key,
			array(
				'label'   => $field['label'],
				'section' => $field['section'],
				'type'    => $field['type'],
			)
		);
	}
}
add_action( 'customize_register', 'konstanta_customize_register' );
