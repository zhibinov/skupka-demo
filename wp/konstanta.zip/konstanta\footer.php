<?php
/**
 * Подвал сайта.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$konstanta_email   = konstanta_opt( 'email' );
$konstanta_privacy = konstanta_page_url( 'privacy' );
$konstanta_consent = konstanta_page_url( 'consent' );
$konstanta_offer   = konstanta_page_url( 'offer' );
?>
</main>

<footer class="footer" id="contacts">
	<div class="container footer__grid">
		<div class="footer__brand">
			<?php if ( has_custom_logo() ) : ?>
				<div class="logo logo--footer logo--custom"><?php the_custom_logo(); ?></div>
			<?php else : ?>
				<a class="logo logo--footer" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( konstanta_opt( 'brand_name' ) ); ?> — на главную">
					<?php echo konstanta_logo_mark(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<span class="logo__text"><strong><?php echo esc_html( konstanta_opt( 'brand_name' ) ); ?></strong><small><?php echo esc_html( konstanta_opt( 'brand_tagline' ) ); ?></small></span>
				</a>
			<?php endif; ?>
			<p><?php echo esc_html( konstanta_opt( 'footer_text' ) ); ?></p>
			<div class="footer__socials">
				<a href="<?php echo esc_url( konstanta_opt( 'telegram_url' ) ); ?>" target="_blank" rel="noopener" aria-label="Telegram"><?php echo konstanta_icon( 'telegram' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
				<a href="<?php echo esc_url( konstanta_opt( 'max_url' ) ); ?>" target="_blank" rel="noopener" aria-label="MAX"><?php echo konstanta_icon( 'max' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
				<a href="<?php echo esc_url( konstanta_phone_href() ); ?>" aria-label="Позвонить"><?php echo konstanta_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
			</div>
		</div>

		<nav class="footer__nav" aria-label="Разделы сайта">
			<h3>Разделы</h3>
			<?php
			konstanta_nav_menu(
				'footer',
				array(
					array( 'Что скупаем', konstanta_section_url( '#materials' ) ),
					array( 'Как работает', konstanta_section_url( '#how' ) ),
					array( 'О компании', konstanta_section_url( '#about' ) ),
					array( 'Наши работы', konstanta_section_url( '#gallery' ) ),
				)
			);
			?>
		</nav>

		<div class="footer__contacts">
			<h3>Контакты</h3>
			<a href="<?php echo esc_url( konstanta_phone_href() ); ?>"><?php echo esc_html( konstanta_opt( 'phone_display' ) ); ?></a>
			<a href="mailto:<?php echo esc_attr( $konstanta_email ); ?>"><?php echo esc_html( $konstanta_email ); ?></a>
			<a href="<?php echo esc_url( konstanta_opt( 'telegram_url' ) ); ?>" target="_blank" rel="noopener">Telegram</a>
			<a href="<?php echo esc_url( konstanta_opt( 'max_url' ) ); ?>" target="_blank" rel="noopener"><?php echo konstanta_icon( 'max' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> MAX</a>
			<span><?php echo esc_html( konstanta_opt( 'address' ) ); ?></span>
			<span><?php echo esc_html( konstanta_opt( 'hours' ) ); ?></span>
		</div>

		<div class="footer__legal">
			<h3>Документы</h3>
			<a href="<?php echo esc_url( $konstanta_privacy ); ?>">Политика конфиденциальности</a>
			<a href="<?php echo esc_url( $konstanta_consent ); ?>">Согласие на обработку персональных данных</a>
			<a href="<?php echo esc_url( $konstanta_offer ); ?>">Публичная оферта</a>
			<p><?php echo esc_html( konstanta_opt( 'legal_name' ) ); ?> · ИНН <?php echo esc_html( konstanta_opt( 'inn' ) ); ?> · ОГРН <?php echo esc_html( konstanta_opt( 'ogrn' ) ); ?></p>
			<p><?php echo esc_html( konstanta_opt( 'offer_note' ) ); ?></p>
		</div>
	</div>

	<div class="container footer__bottom">
		<span>© <span id="year"><?php echo esc_html( wp_date( 'Y' ) ); ?></span> <?php echo esc_html( konstanta_opt( 'legal_name' ) ); ?>. Все права защищены.</span>
		<a class="footer__dev" href="<?php echo esc_url( konstanta_opt( 'dev_url' ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( konstanta_opt( 'dev_text' ) ); ?></a>
		<span><?php echo esc_html( konstanta_opt( 'hours' ) ); ?></span>
	</div>
</footer>

<div class="fab" aria-label="Быстрая связь">
	<a class="fab__item fab__item--tg" href="<?php echo esc_url( konstanta_opt( 'telegram_url' ) ); ?>" target="_blank" rel="noopener" aria-label="Написать в Telegram"><?php echo konstanta_icon( 'telegram' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
	<a class="fab__item fab__item--phone" href="<?php echo esc_url( konstanta_phone_href() ); ?>" aria-label="Позвонить"><?php echo konstanta_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
	<a class="fab__item fab__item--max" href="<?php echo esc_url( konstanta_opt( 'max_url' ) ); ?>" target="_blank" rel="noopener" aria-label="MAX"><?php echo konstanta_icon( 'max' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
</div>

<div class="lightbox" id="lightbox" aria-hidden="true" role="dialog" aria-modal="true" aria-label="Просмотр фото">
	<button class="lightbox__close" id="lightboxClose" type="button" aria-label="Закрыть"><?php echo konstanta_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
	<button class="lightbox__nav lightbox__nav--prev" id="lightboxPrev" type="button" aria-label="Предыдущее фото">‹</button>
	<img class="lightbox__img" id="lightboxImg" alt="">
	<button class="lightbox__nav lightbox__nav--next" id="lightboxNext" type="button" aria-label="Следующее фото">›</button>
</div>

<div class="toast" id="toast" role="status" aria-live="polite"></div>

<div class="cookie-banner" id="cookieBanner" role="dialog" aria-live="polite" aria-label="Уведомление об использовании cookie">
	<p>Мы используем cookie для работы сайта и анализа посещаемости. Продолжая пользоваться сайтом, вы соглашаетесь с <a href="<?php echo esc_url( $konstanta_privacy . '#cookies' ); ?>">политикой конфиденциальности</a>.</p>
	<div class="cookie-banner__actions">
		<button class="btn btn--accent btn--sm" type="button" id="cookieAccept">Принять</button>
		<a class="btn btn--outline btn--sm" href="<?php echo esc_url( $konstanta_privacy . '#cookies' ); ?>">Подробнее</a>
	</div>
</div>

<?php wp_footer(); ?>
</body>
</html>
