<?php
/**
 * Тема «Константа».
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KONSTANTA_VERSION', '1.0.0' );
define( 'KONSTANTA_DIR', get_template_directory() );
define( 'KONSTANTA_URI', get_template_directory_uri() );

require_once KONSTANTA_DIR . '/inc/helpers.php';
require_once KONSTANTA_DIR . '/inc/setup.php';
require_once KONSTANTA_DIR . '/inc/options.php';
require_once KONSTANTA_DIR . '/inc/post-types.php';
require_once KONSTANTA_DIR . '/inc/blocks.php';
require_once KONSTANTA_DIR . '/inc/forms.php';
require_once KONSTANTA_DIR . '/inc/demo-content.php';
