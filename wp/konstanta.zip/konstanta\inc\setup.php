<?php
/**
 * Настройка темы, стили и скрипты.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Базовые возможности темы.
 */
function konstanta_setup() {
	load_theme_textdomain( 'konstanta', KONSTANTA_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 48,
			'width'       => 220,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'wp-block-styles' );
	add_editor_style(
		array(
			'assets/css/site.css',
			'assets/css/editor.css',
		)
	);

	register_nav_menus(
		array(
			'primary' => 'Основное меню',
			'footer'  => 'Меню в подвале',
		)
	);

	add_image_size( 'konstanta-material', 800, 600, true );
	add_image_size( 'konstanta-gallery', 1200, 900, true );
	add_image_size( 'konstanta-vehicle', 900, 675, true );
}
add_action( 'after_setup_theme', 'konstanta_setup' );

/**
 * Ширина контента для встраиваемых элементов.
 */
function konstanta_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'konstanta_content_width', 1240 );
}
add_action( 'after_setup_theme', 'konstanta_content_width', 0 );

/**
 * Стили и скрипты фронтенда.
 */
function konstanta_enqueue_assets() {
	wp_enqueue_style(
		'konstanta-fonts',
		'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Unbounded:wght@400;500;600&display=swap',
		array(),
		null
	);

	wp_enqueue_style(
		'konstanta-site',
		KONSTANTA_URI . '/assets/css/site.css',
		array( 'konstanta-fonts' ),
		KONSTANTA_VERSION
	);

	wp_enqueue_style(
		'konstanta-wp',
		KONSTANTA_URI . '/assets/css/wp.css',
		array( 'konstanta-site' ),
		KONSTANTA_VERSION
	);

	if ( is_page_template( 'templates/legal.php' ) ) {
		wp_enqueue_style(
			'konstanta-legal',
			KONSTANTA_URI . '/assets/css/legal.css',
			array( 'konstanta-site' ),
			KONSTANTA_VERSION
		);
	}

	wp_enqueue_script(
		'konstanta-main',
		KONSTANTA_URI . '/assets/js/main.js',
		array(),
		KONSTANTA_VERSION,
		true
	);

	wp_localize_script(
		'konstanta-main',
		'KonstantaData',
		array(
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'homeUrl'     => home_url( '/' ),
			'formError'   => 'Не удалось отправить заявку. Позвоните нам или напишите в Telegram.',
			'fileError'   => 'Файл больше 10 МБ. Прикрепите файл меньшего размера.',
			'sendingText' => 'Отправляем…',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'konstanta_enqueue_assets' );

/**
 * Скрипты и стили редактора блоков.
 */
function konstanta_enqueue_editor_assets() {
	wp_enqueue_style(
		'konstanta-editor',
		KONSTANTA_URI . '/assets/css/editor.css',
		array(),
		KONSTANTA_VERSION
	);

	wp_enqueue_script(
		'konstanta-blocks-editor',
		KONSTANTA_URI . '/assets/js/blocks.js',
		array(
			'wp-blocks',
			'wp-element',
			'wp-components',
			'wp-block-editor',
			'wp-server-side-render',
			'wp-i18n',
			'wp-data',
			'wp-api-fetch',
		),
		KONSTANTA_VERSION,
		true
	);

	wp_localize_script( 'konstanta-blocks-editor', 'KonstantaBlocks', konstanta_get_editor_config() );
}
add_action( 'enqueue_block_editor_assets', 'konstanta_enqueue_editor_assets' );

/**
 * Preconnect к Google Fonts.
 *
 * @param array  $urls          Ресурсы.
 * @param string $relation_type Тип связи.
 * @return array
 */
function konstanta_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = array(
			'href' => 'https://fonts.gstatic.com',
			'crossorigin',
		);
	}

	return $urls;
}
add_filter( 'wp_resource_hints', 'konstanta_resource_hints', 10, 2 );

/**
 * Категория блоков темы.
 *
 * @param array $categories Категории.
 * @return array
 */
function konstanta_block_category( $categories ) {
	return array_merge(
		array(
			array(
				'slug'  => 'konstanta',
				'title' => 'Константа',
				'icon'  => null,
			),
		),
		$categories
	);
}
add_filter( 'block_categories_all', 'konstanta_block_category' );

/**
 * CSS-классы body.
 *
 * @param array $classes Классы.
 * @return array
 */
function konstanta_body_classes( $classes ) {
	if ( is_page_template( 'templates/legal.php' ) ) {
		$classes[] = 'legal-page';
	}

	if ( is_front_page() ) {
		$classes[] = 'is-konstanta-front';
	}

	return $classes;
}
add_filter( 'body_class', 'konstanta_body_classes' );
