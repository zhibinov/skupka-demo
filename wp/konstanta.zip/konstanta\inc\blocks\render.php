<?php
/**
 * Серверный рендер блоков.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * HTML-уведомление для администратора.
 *
 * @param string $text Текст.
 * @return string
 */
function konstanta_admin_notice( $text ) {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return '';
	}

	return '<p class="konstanta-admin-notice">' . esc_html( $text ) . '</p>';
}

/**
 * Hero.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_hero( $attributes ) {
	$a        = wp_parse_args( $attributes, konstanta_block_defaults( 'hero' ) );
	$image    = konstanta_image_url( isset( $a['image'] ) ? (int) $a['image'] : 0, 'hero.jpg' );
	$primary  = $a['primary_url'] ? $a['primary_url'] : '#calc';
	$secondary = $a['secondary_url'] ? $a['secondary_url'] : konstanta_opt( 'telegram_url' );

	ob_start();
	?>
	<section class="hero" id="top">
		<div class="hero__bg" style="--hero-image:url('<?php echo esc_url( $image ); ?>')" aria-hidden="true"></div>
		<div class="container hero__inner">
			<div class="hero__content reveal">
				<div class="hero__eyebrow"><span class="dot"></span> <?php echo esc_html( $a['eyebrow'] ); ?></div>
				<h1 class="hero__title"><?php echo esc_html( $a['title_before'] ); ?> <span><?php echo esc_html( $a['title_accent'] ); ?></span><?php echo esc_html( $a['title_after'] ); ?></h1>
				<p class="hero__lead"><?php echo wp_kses_post( $a['lead'] ); ?></p>
				<div class="hero__actions">
					<a class="btn btn--accent btn--lg" href="<?php echo esc_url( $primary ); ?>"><?php echo esc_html( $a['primary_text'] ); ?> <?php echo konstanta_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
					<a class="btn btn--ghost btn--lg" href="<?php echo esc_url( $secondary ); ?>" target="_blank" rel="noopener">
						<?php echo konstanta_icon( 'telegram' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php echo esc_html( $a['secondary_text'] ); ?>
					</a>
				</div>
				<?php if ( ! empty( $a['trust'] ) && is_array( $a['trust'] ) ) : ?>
					<ul class="hero__trust">
						<?php foreach ( $a['trust'] as $item ) : ?>
							<?php if ( empty( $item['text'] ) ) : ?>
								<?php continue; ?>
							<?php endif; ?>
							<li><?php echo konstanta_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php echo esc_html( $item['text'] ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
		</div>

		<?php if ( ! empty( $a['stats'] ) && is_array( $a['stats'] ) ) : ?>
			<div class="container">
				<dl class="hero__stats">
					<?php foreach ( $a['stats'] as $stat ) : ?>
						<?php if ( empty( $stat['value'] ) && empty( $stat['label'] ) ) : ?>
							<?php continue; ?>
						<?php endif; ?>
						<div>
							<dt><?php echo esc_html( $stat['value'] ); ?></dt>
							<dd><?php echo esc_html( $stat['label'] ); ?></dd>
						</div>
					<?php endforeach; ?>
				</dl>
			</div>
		<?php endif; ?>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Бегущая строка.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_marquee( $attributes ) {
	$a = wp_parse_args( $attributes, konstanta_block_defaults( 'marquee' ) );

	if ( empty( $a['items'] ) || ! is_array( $a['items'] ) ) {
		return '';
	}

	$labels = array();
	foreach ( $a['items'] as $item ) {
		if ( ! empty( $item['text'] ) ) {
			$labels[] = $item['text'];
		}
	}

	if ( ! $labels ) {
		return '';
	}

	ob_start();
	?>
	<div class="marquee" aria-hidden="true">
		<div class="marquee__track">
			<?php for ( $n = 0; $n < 2; $n++ ) : ?>
				<?php foreach ( $labels as $label ) : ?>
					<span><?php echo esc_html( $label ); ?></span>
				<?php endforeach; ?>
			<?php endfor; ?>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Материалы.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_materials( $attributes ) {
	$a      = wp_parse_args( $attributes, konstanta_block_defaults( 'materials' ) );
	$query  = new WP_Query(
		array(
			'post_type'           => 'material',
			'posts_per_page'      => -1,
			'post_status'         => 'publish',
			'orderby'             => array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			),
			'ignore_sticky_posts' => true,
		)
	);

	$terms = get_terms(
		array(
			'taxonomy'   => 'material_category',
			'hide_empty' => true,
		)
	);
	$terms = is_wp_error( $terms ) ? array() : $terms;

	ob_start();
	?>
	<section class="section" id="materials">
		<div class="container">
			<div class="section-head reveal">
				<span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo wp_kses_post( $a['description'] ); ?></p>
			</div>

			<?php if ( $a['show_filters'] && $terms ) : ?>
				<div class="filters reveal" role="group" aria-label="Фильтр категорий">
					<button class="filter is-active" type="button" data-filter="all" aria-pressed="true">Все</button>
					<?php foreach ( $terms as $term ) : ?>
						<button class="filter" type="button" data-filter="<?php echo esc_attr( $term->slug ); ?>" aria-pressed="false"><?php echo esc_html( $term->name ); ?></button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( $query->have_posts() ) : ?>
				<div class="materials-grid" id="materialsGrid">
					<?php $index = 0; ?>
					<?php while ( $query->have_posts() ) : ?>
						<?php
						$query->the_post();
						$index++;
						$post_terms = get_the_terms( get_the_ID(), 'material_category' );
						$cat        = ( $post_terms && ! is_wp_error( $post_terms ) ) ? $post_terms[0]->slug : '';
						$image      = get_the_post_thumbnail(
							get_the_ID(),
							'konstanta-material',
							array(
								'class'   => '',
								'loading' => 'lazy',
								'alt'     => get_the_title(),
							)
						);
						if ( ! $image ) {
							$image = konstanta_image_html( 0, 'placeholder.svg', get_the_title() );
						}
						?>
						<article class="material-card reveal" data-cat="<?php echo esc_attr( $cat ); ?>">
							<div class="material-card__media">
								<?php echo $image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span class="material-card__tag"><?php echo esc_html( str_pad( (string) $index, 2, '0', STR_PAD_LEFT ) ); ?></span>
							</div>
							<div class="material-card__body">
								<h3><?php the_title(); ?></h3>
								<p><?php echo esc_html( konstanta_excerpt( get_the_ID(), 18 ) ); ?></p>
								<a class="material-card__link" href="<?php echo esc_url( konstanta_section_url( '#calc' ) ); ?>">Оценить <?php echo konstanta_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
							</div>
						</article>
					<?php endwhile; ?>
				</div>
			<?php else : ?>
				<?php echo konstanta_admin_notice( 'Добавьте материалы в разделе «Материалы», чтобы заполнить этот блок.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>

			<?php if ( ! empty( $a['note'] ) ) : ?>
				<p class="materials-note reveal"><?php
					$note = esc_html( $a['note'] );
					$note = str_replace( 'Напишите нам', '<a href="' . esc_url( konstanta_section_url( '#calc' ) ) . '">Напишите нам</a>', $note );
					echo wp_kses_post( $note );
				?></p>
			<?php endif; ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Этапы.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_steps( $attributes ) {
	$a = wp_parse_args( $attributes, konstanta_block_defaults( 'steps' ) );

	ob_start();
	?>
	<section class="section" id="how">
		<div class="container">
			<div class="section-head reveal">
				<span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo wp_kses_post( $a['description'] ); ?></p>
			</div>

			<?php if ( ! empty( $a['items'] ) && is_array( $a['items'] ) ) : ?>
				<ol class="steps">
					<?php $index = 0; ?>
					<?php foreach ( $a['items'] as $item ) : ?>
						<?php
						if ( empty( $item['title'] ) && empty( $item['text'] ) ) {
							continue;
						}
						$index++;
						?>
						<li class="step reveal">
							<span class="step__num"><?php echo esc_html( str_pad( (string) $index, 2, '0', STR_PAD_LEFT ) ); ?></span>
							<div class="step__icon"><?php echo konstanta_icon( sanitize_key( $item['icon'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
							<h3><?php echo esc_html( $item['title'] ); ?></h3>
							<p><?php echo wp_kses_post( $item['text'] ); ?></p>
						</li>
					<?php endforeach; ?>
				</ol>
			<?php endif; ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Преимущества.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_features( $attributes ) {
	$a = wp_parse_args( $attributes, konstanta_block_defaults( 'features' ) );

	ob_start();
	?>
	<section class="section section--cream" id="why">
		<div class="container">
			<div class="section-head reveal">
				<span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo wp_kses_post( $a['description'] ); ?></p>
			</div>

			<?php if ( ! empty( $a['items'] ) && is_array( $a['items'] ) ) : ?>
				<div class="features">
					<?php foreach ( $a['items'] as $item ) : ?>
						<?php
						if ( empty( $item['title'] ) && empty( $item['text'] ) ) {
							continue;
						}
						?>
						<article class="feature reveal">
							<div class="feature__icon"><?php echo konstanta_icon( sanitize_key( $item['icon'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
							<h3><?php echo esc_html( $item['title'] ); ?></h3>
							<p><?php echo wp_kses_post( $item['text'] ); ?></p>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * О компании.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_about( $attributes ) {
	$a     = wp_parse_args( $attributes, konstanta_block_defaults( 'about' ) );
	$image = konstanta_image_html(
		isset( $a['image'] ) ? (int) $a['image'] : 0,
		'about.jpg',
		'Погрузчик вывозит продукцию с площадки',
		'about__img',
		array(
			'width'  => 1536,
			'height' => 1024,
		)
	);

	ob_start();
	?>
	<section class="section" id="about">
		<div class="container about">
			<div class="about__media reveal">
				<?php echo $image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<div class="about__badge"><strong><?php echo esc_html( $a['badge_value'] ); ?></strong><span><?php echo esc_html( $a['badge_label'] ); ?></span></div>
			</div>

			<div class="about__content reveal" data-delay="120">
				<span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo wp_kses_post( $a['text1'] ); ?></p>
				<p><?php echo wp_kses_post( $a['text2'] ); ?></p>
				<?php if ( ! empty( $a['list'] ) && is_array( $a['list'] ) ) : ?>
					<ul class="about__list">
						<?php foreach ( $a['list'] as $item ) : ?>
							<?php if ( empty( $item['text'] ) ) : ?>
								<?php continue; ?>
							<?php endif; ?>
							<li><?php echo konstanta_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php echo esc_html( $item['text'] ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<a class="btn btn--dark" href="<?php echo esc_url( $a['button_url'] ? $a['button_url'] : '#calc' ); ?>"><?php echo esc_html( $a['button_text'] ); ?> <?php echo konstanta_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Транспорт.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_transport( $attributes ) {
	$a     = wp_parse_args( $attributes, konstanta_block_defaults( 'transport' ) );
	$query = new WP_Query(
		array(
			'post_type'           => 'vehicle',
			'posts_per_page'      => -1,
			'post_status'         => 'publish',
			'orderby'             => array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			),
			'ignore_sticky_posts' => true,
		)
	);

	$fallbacks = array( 'transport/gazelle.jpg', 'transport/lomovoz.jpg', 'transport/dlinnomer.jpg' );

	ob_start();
	?>
	<section class="section section--cream" id="transport">
		<div class="container">
			<div class="section-head reveal">
				<span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo wp_kses_post( $a['description'] ); ?></p>
			</div>

			<?php if ( $query->have_posts() ) : ?>
				<div class="transport-grid">
					<?php $index = 0; ?>
					<?php while ( $query->have_posts() ) : ?>
						<?php
						$query->the_post();
						$capacity   = get_post_meta( get_the_ID(), '_konstanta_vehicle_capacity', true );
						$features   = get_post_meta( get_the_ID(), '_konstanta_vehicle_features', true );
						$features   = konstanta_to_array( $features );
						$fallback   = $fallbacks[ $index % count( $fallbacks ) ];
						$image      = get_the_post_thumbnail(
							get_the_ID(),
							'konstanta-vehicle',
							array(
								'loading' => 'lazy',
								'alt'     => get_the_title(),
							)
						);
						if ( ! $image ) {
							$image = konstanta_image_html( 0, $fallback, get_the_title() );
						}
						$description = konstanta_excerpt( get_the_ID(), 18 );
						?>
						<article class="vehicle-card reveal" data-delay="<?php echo esc_attr( (string) ( $index * 120 ) ); ?>">
							<div class="vehicle-card__media">
								<?php echo $image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<?php if ( $capacity ) : ?>
									<span class="vehicle-card__tag"><?php echo esc_html( $capacity ); ?></span>
								<?php endif; ?>
							</div>
							<div class="vehicle-card__body">
								<h3><?php the_title(); ?></h3>
								<p><?php echo esc_html( $description ); ?></p>
								<?php if ( $features ) : ?>
									<ul>
										<?php foreach ( $features as $feature ) : ?>
											<li><?php echo esc_html( $feature ); ?></li>
										<?php endforeach; ?>
									</ul>
								<?php endif; ?>
								<a class="btn btn--dark btn--full" href="<?php echo esc_url( konstanta_section_url( '#calc' ) ); ?>">Заказать авто <?php echo konstanta_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
							</div>
						</article>
						<?php $index++; ?>
					<?php endwhile; ?>
				</div>
			<?php else : ?>
				<?php echo konstanta_admin_notice( 'Добавьте автомобили в разделе «Транспорт», чтобы заполнить этот блок.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Галерея.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_gallery( $attributes ) {
	$a      = wp_parse_args( $attributes, konstanta_block_defaults( 'gallery' ) );
	$images = ! empty( $a['images'] ) && is_array( $a['images'] ) ? $a['images'] : array();

	$fallback_images = array(
		array(
			'file' => 'gallery/7.jpg',
			'alt'  => 'Трансформаторы, выкупленные у предприятия',
		),
		array(
			'file' => 'gallery/01_kabel.jpg',
			'alt'  => 'Кабель на площадке',
		),
		array(
			'file' => 'gallery/02_pogruzka_produkcii.jpg',
			'alt'  => 'Погрузка продукции манипулятором',
		),
		array(
			'file' => 'gallery/03_truby_i_zapornaya_armatura.jpg',
			'alt'  => 'Трубы и запорная арматура',
		),
		array(
			'file' => 'gallery/04_starye_elektrodvigateli.jpg',
			'alt'  => 'Электродвигатели',
		),
		array(
			'file' => 'gallery/05_smeshannaya_produkciya.jpg',
			'alt'  => 'Смешанная продукция',
		),
		array(
			'file' => 'gallery/06_kabel_i_provod.jpg',
			'alt'  => 'Кабель и провод',
		),
	);

	$slides = array();

	if ( $images ) {
		foreach ( $images as $image_id ) {
			$image_id = (int) $image_id;
			if ( ! $image_id ) {
				continue;
			}
			$full = wp_get_attachment_image_url( $image_id, 'full' );
			$alt  = get_post_meta( $image_id, '_wp_attachment_image_alt', true );
			if ( ! $alt ) {
				$alt = get_the_title( $image_id );
			}
			$thumb = wp_get_attachment_image(
				$image_id,
				'konstanta-gallery',
				false,
				array(
					'loading' => 'lazy',
					'alt'     => $alt,
				)
			);
			if ( $full && $thumb ) {
				$slides[] = array(
					'full'  => $full,
					'thumb' => $thumb,
					'alt'   => $alt,
				);
			}
		}
	}

	if ( ! $slides ) {
		foreach ( $fallback_images as $item ) {
			$slides[] = array(
				'full'  => konstanta_image_url( 0, $item['file'] ),
				'thumb' => konstanta_image_html( 0, $item['file'], $item['alt'] ),
				'alt'   => $item['alt'],
			);
		}
	}

	$total = count( $slides );

	ob_start();
	?>
	<section class="section section--dark" id="gallery">
		<div class="container">
			<div class="section-head section-head--light reveal">
				<span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo wp_kses_post( $a['description'] ); ?></p>
			</div>

			<div class="gallery-slider reveal" id="gallerySlider">
				<div class="gallery-slider__viewport" id="galleryViewport" tabindex="0" aria-label="Галерея фотографий последних скупок">
					<div class="gallery-slider__track" id="galleryTrack">
						<?php foreach ( $slides as $slide ) : ?>
							<button class="gallery-slide" type="button" data-full="<?php echo esc_url( $slide['full'] ); ?>" aria-label="Открыть фото: <?php echo esc_attr( $slide['alt'] ); ?>">
								<?php echo $slide['thumb']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span class="gallery-slide__zoom"><?php echo konstanta_icon( 'plus' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							</button>
						<?php endforeach; ?>
					</div>
				</div>
				<div class="gallery-slider__controls">
					<button class="gallery-slider__arrow" id="galleryPrev" type="button" aria-label="Предыдущее фото"><?php echo konstanta_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
					<span class="gallery-slider__counter"><strong id="galleryCurrent">01</strong> / <span id="galleryTotal"><?php echo esc_html( str_pad( (string) $total, 2, '0', STR_PAD_LEFT ) ); ?></span></span>
					<button class="gallery-slider__arrow gallery-slider__arrow--next" id="galleryNext" type="button" aria-label="Следующее фото"><?php echo konstanta_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
				</div>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Контакты и форма.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_contact( $attributes ) {
	$a       = wp_parse_args( $attributes, konstanta_block_defaults( 'contact' ) );
	$sent    = isset( $_GET['sent'] ) && is_string( $_GET['sent'] ) ? sanitize_text_field( wp_unslash( $_GET['sent'] ) ) : '';
	$success = '1' === $sent;
	$email   = konstanta_opt( 'email' );
	$privacy = konstanta_page_url( 'privacy' );
	$consent = konstanta_page_url( 'consent' );

	$contacts = array(
		array(
			'icon'  => 'phone',
			'label' => 'Телефон',
			'value' => konstanta_opt( 'phone_display' ),
			'url'   => konstanta_phone_href(),
		),
		array(
			'icon'  => 'telegram',
			'label' => 'Telegram',
			'value' => 'Написать в Telegram',
			'url'   => konstanta_opt( 'telegram_url' ),
		),
		array(
			'icon'  => 'max',
			'label' => 'MAX',
			'value' => 'Написать в MAX',
			'url'   => konstanta_opt( 'max_url' ),
		),
		array(
			'icon'  => 'mail',
			'label' => 'Email',
			'value' => $email,
			'url'   => 'mailto:' . $email,
		),
		array(
			'icon'  => 'map',
			'label' => 'Адрес',
			'value' => konstanta_opt( 'address' ),
			'url'   => konstanta_opt( 'address_url' ),
		),
	);

	ob_start();
	?>
	<section class="section section--dark" id="calc">
		<div class="container calc">
			<div class="calc__content reveal">
				<span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo wp_kses_post( $a['description'] ); ?></p>

				<ul class="calc__contacts">
					<?php foreach ( $contacts as $contact ) : ?>
						<li>
							<?php echo konstanta_icon( $contact['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<div>
								<span><?php echo esc_html( $contact['label'] ); ?></span>
								<?php if ( $contact['url'] ) : ?>
									<a href="<?php echo esc_url( $contact['url'] ); ?>"<?php echo 'phone' === $contact['icon'] ? '' : ' target="_blank" rel="noopener"'; ?>><?php echo esc_html( $contact['value'] ); ?></a>
								<?php else : ?>
									<strong><?php echo esc_html( $contact['value'] ); ?></strong>
								<?php endif; ?>
							</div>
						</li>
					<?php endforeach; ?>
					<li>
						<?php echo konstanta_icon( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<div><span>Режим работы</span><strong><?php echo esc_html( konstanta_opt( 'hours' ) ); ?></strong></div>
					</li>
				</ul>
			</div>

			<div class="calc__form-wrap reveal" data-delay="120">
				<?php if ( 'error' === $sent ) : ?>
					<p class="calc-error">Не удалось отправить заявку. Проверьте поля и попробуйте ещё раз или позвоните нам.</p>
				<?php endif; ?>
				<form class="calc-form" id="calcForm" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" enctype="multipart/form-data" novalidate<?php echo $success ? ' hidden' : ''; ?>>
					<input type="hidden" name="action" value="konstanta_request">
					<?php wp_nonce_field( 'konstanta_request', 'konstanta_nonce' ); ?>
					<div class="form-hp" aria-hidden="true">
						<label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label>
					</div>
					<div class="calc-form__row">
						<label class="field"><span>Имя</span><input type="text" name="name" placeholder="Как к вам обращаться" autocomplete="name" required></label>
						<label class="field"><span>Телефон</span><input type="tel" name="phone" placeholder="+7 (___) ___-__-__" autocomplete="tel" inputmode="tel" required></label>
					</div>
					<div class="calc-form__row">
						<label class="field"><span>Категория</span>
							<select name="category">
								<option>Кабель и провод</option>
								<option>Металлопрокат</option>
								<option>Запорная арматура</option>
								<option>Электрика и оборудование</option>
								<option>Другое</option>
							</select>
						</label>
						<label class="field"><span>Объём, кг</span><input type="text" name="weight" placeholder="Например, 500 кг" inputmode="numeric"></label>
					</div>
					<label class="field"><span>Комментарий</span><textarea name="comment" rows="3" placeholder="Марка, состояние, адрес объекта"></textarea></label>
					<label class="upload" for="files">
						<?php echo konstanta_icon( 'upload' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><strong>Прикрепить фото</strong><small id="fileName">JPG, PNG, PDF — до 10 МБ</small></span>
						<input type="file" id="files" name="files[]" multiple accept="image/*,.pdf">
					</label>
					<label class="checkbox">
						<input type="checkbox" name="consent" required>
						<span>Даю <a href="<?php echo esc_url( $consent ); ?>" target="_blank" rel="noopener">согласие на обработку персональных данных</a> и принимаю <a href="<?php echo esc_url( $privacy ); ?>" target="_blank" rel="noopener">политику конфиденциальности</a></span>
					</label>
					<button class="btn btn--accent btn--full btn--lg" type="submit">Узнать стоимость <?php echo konstanta_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
					<p class="calc-form__note"><?php echo esc_html( $a['form_note'] ); ?></p>
				</form>

				<div class="calc-success" id="calcSuccess"<?php echo $success ? '' : ' hidden'; ?>>
					<div class="calc-success__icon"><?php echo konstanta_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
					<h3>Заявка отправлена</h3>
					<p>Спасибо! Мы получили вашу заявку и свяжемся с вами в ближайшее время. Если удобнее, напишите на <a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a> или позвоните.</p>
					<div class="calc-success__actions">
						<a class="btn btn--accent" href="<?php echo esc_url( konstanta_phone_href() ); ?>">Позвонить</a>
						<button class="btn btn--ghost" type="button" id="calcAgain">Отправить ещё</button>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * FAQ.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_faq( $attributes ) {
	$a     = wp_parse_args( $attributes, konstanta_block_defaults( 'faq' ) );
	$query = new WP_Query(
		array(
			'post_type'           => 'faq',
			'posts_per_page'      => -1,
			'post_status'         => 'publish',
			'orderby'             => array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			),
			'ignore_sticky_posts' => true,
		)
	);
	$url = $a['button_url'] ? $a['button_url'] : konstanta_opt( 'telegram_url' );

	ob_start();
	?>
	<section class="section" id="faq">
		<div class="container faq">
			<div class="faq__head reveal">
				<span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo wp_kses_post( $a['description'] ); ?></p>
				<a class="btn btn--ghost" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener">
					<?php echo konstanta_icon( 'telegram' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php echo esc_html( $a['button_text'] ); ?>
				</a>
			</div>

			<?php if ( $query->have_posts() ) : ?>
				<div class="faq__list reveal" data-delay="120">
					<?php while ( $query->have_posts() ) : ?>
						<?php $query->the_post(); ?>
						<details class="faq-item">
							<summary><?php the_title(); ?><span class="faq-item__icon" aria-hidden="true"></span></summary>
							<div class="faq-item__body"><?php echo wp_kses_post( apply_filters( 'the_content', get_the_content() ) ); ?></div>
						</details>
					<?php endwhile; ?>
				</div>
			<?php else : ?>
				<?php echo konstanta_admin_notice( 'Добавьте вопросы в разделе «FAQ», чтобы заполнить этот блок.' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Финальный CTA.
 *
 * @param array $attributes Атрибуты.
 * @return string
 */
function konstanta_render_cta( $attributes ) {
	$a = wp_parse_args( $attributes, konstanta_block_defaults( 'cta' ) );

	ob_start();
	?>
	<section class="cta">
		<div class="container cta__inner reveal">
			<div>
				<span class="eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo wp_kses_post( $a['description'] ); ?></p>
			</div>
			<div class="cta__actions">
				<a class="btn btn--accent btn--lg" href="<?php echo esc_url( $a['primary_url'] ? $a['primary_url'] : '#calc' ); ?>"><?php echo esc_html( $a['primary_text'] ); ?> <?php echo konstanta_icon( 'arrow' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
				<a class="btn btn--ghost btn--lg" href="<?php echo esc_url( konstanta_opt( 'telegram_url' ) ); ?>" target="_blank" rel="noopener"><?php echo konstanta_icon( 'telegram' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> Написать в Telegram</a>
				<a class="btn btn--ghost btn--lg" href="<?php echo esc_url( konstanta_opt( 'max_url' ) ); ?>" target="_blank" rel="noopener"><?php echo konstanta_icon( 'max' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> Написать в MAX</a>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}
