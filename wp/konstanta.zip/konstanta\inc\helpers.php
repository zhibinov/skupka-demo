<?php
/**
 * Вспомогательные функции темы.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Значения по умолчанию.
 *
 * @return array
 */
function konstanta_defaults() {
	return array(
		'brand_name'    => 'Константа',
		'brand_tagline' => 'промышленная скупка',
		'phone_display' => '+7 905 622-21-22',
		'phone_link'    => '+7 905 622-21-22',
		'telegram_url'  => 'https://t.me/+79056222122',
		'max_url'       => 'https://max.ru/u/f9LHodD0cOJMlTKvxi_rbC6VbO87elEfIggZckKfSeAaSG1NAwWXDLCsMxg',
		'email'         => 'std.lebedev@yandex.ru',
		'address'       => 'Москва, Ленинградское шоссе, д. 17, стр. 1',
		'address_url'   => 'https://yandex.ru/maps/?text=%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%2C%20%D0%9B%D0%B5%D0%BD%D0%B8%D0%BD%D0%B3%D1%80%D0%B0%D0%B4%D1%81%D0%BA%D0%BE%D0%B5%20%D1%88%D0%BE%D1%81%D1%81%D0%B5%2C%20%D0%B4.%2017%2C%20%D1%81%D1%82%D1%80.%201',
		'hours'         => 'Вся Россия · ежедневно, 24/7',
		'legal_name'    => 'ООО «Константа»',
		'inn'           => '7203428524',
		'ogrn'          => '1177232025442',
		'offer_note'    => 'Информация на сайте не является публичной офертой.',
		'footer_text'   => 'Скупка кабеля, металлопроката, запорной арматуры, электрики и промышленного оборудования. Работаем по всей России.',
		'dev_text'      => 'Разработка сайта - СайтыиДизайн.рф',
		'dev_url'       => 'http://sitesanddesign.ru/',
	);
}

/**
 * Значение настройки темы.
 *
 * @param string $key Ключ.
 * @return string
 */
function konstanta_opt( $key ) {
	$defaults = konstanta_defaults();
	$default  = isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';

	return (string) get_theme_mod( $key, $default );
}

/**
 * URL секции главной страницы.
 *
 * @param string $hash Якорь.
 * @return string
 */
function konstanta_section_url( $hash ) {
	$hash = $hash ? '#' . ltrim( $hash, '#' ) : '';

	if ( is_front_page() ) {
		return $hash ? $hash : home_url( '/' );
	}

	return home_url( '/' ) . $hash;
}

/**
 * URL страницы по ярлыку.
 *
 * @param string $slug     Ярлык.
 * @param string $fallback Запасной путь.
 * @return string
 */
function konstanta_page_url( $slug, $fallback = '' ) {
	$page = get_page_by_path( $slug );

	if ( $page instanceof WP_Post ) {
		return get_permalink( $page );
	}

	if ( ! $fallback ) {
		$fallback = '/' . trim( $slug, '/' ) . '/';
	}

	return home_url( $fallback );
}

/**
 * Телефон для href.
 *
 * @return string
 */
function konstanta_phone_href() {
	$raw    = konstanta_opt( 'phone_link' );
	$digits = preg_replace( '/\D+/', '', $raw );

	if ( ! $digits ) {
		return '#';
	}

	return 'tel:+' . ltrim( $digits, '+' );
}

/**
 * Набор SVG-иконок.
 *
 * @return array
 */
function konstanta_icons() {
	return array(
		'phone'    => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.78.62 2.63a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.45-1.18a2 2 0 0 1 2.11-.45c.85.29 1.73.5 2.63.62A2 2 0 0 1 22 16.92z"/>',
		),
		'telegram' => array(
			'viewBox' => '0 0 24 24',
			'fill'    => true,
			'markup'  => '<path d="M21.7 3.3 2.9 10.6c-1 .4-1 1.8.1 2.1l4.7 1.4 1.8 5.4c.3.9 1.4 1.1 2 .4l2.5-2.8 4.7 3.4c.7.5 1.7.1 1.9-.7l3-14.2c.2-1-.8-1.8-1.7-1.4Z"/>',
		),
		'max'      => array(
			'viewBox' => '0 0 102 100',
			'fill'    => true,
			'markup'  => '<path fill-rule="evenodd" clip-rule="evenodd" d="M50.76 0c27.53 0 49.12 22.34 49.12 49.89S77.61 99.23 51.02 99.23c-9.43 0-14.01-1.33-21.37-6.54-.5-.36-1.2-.26-1.63.19-5.66 6.04-20.17 10.28-20.83 2.03C7.19 80.53 0 71.18 0 49.61 0 21.3 23.22 0 50.76 0m.77 24.55c-13.07-.68-23.26 8.39-25.51 22.58-1.86 11.75 1.44 26.07 4.26 26.8 1.2.3 4.08-1.9 6.18-3.88.4-.37.99-.44 1.45-.15 3.27 2 6.97 3.5 11.05 3.71 13.42.7 25.3-9.8 26-23.21.71-13.42-10.01-25.14-23.43-25.85"/>',
		),
		'arrow'    => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M5 12h14M13 6l6 6-6 6"/>',
		),
		'check'    => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M20 6 9 17l-5-5"/>',
		),
		'clock'    => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
		),
		'truck'    => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M1 5h14v11H1zM15 9h4l3 3v4h-7V9z"/><circle cx="5.5" cy="18.5" r="2"/><circle cx="18.5" cy="18.5" r="2"/>',
		),
		'scale'    => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M12 3v18M5 7h14M7 7l-3 7a3 3 0 0 0 6 0L7 7zM17 7l-3 7a3 3 0 0 0 6 0l-3-7zM8 21h8"/>',
		),
		'doc'      => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
		),
		'shield'   => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
		),
		'wallet'   => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M3 10h18M16 14h2"/>',
		),
		'users'    => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
		),
		'plus'     => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M12 5v14M5 12h14"/>',
		),
		'close'    => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M18 6 6 18M6 6l12 12"/>',
		),
		'map'      => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M21 10c0 7-9 12-9 12S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
		),
		'mail'     => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
		),
		'upload'   => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M17 8l-5-5-5 5M12 3v12"/>',
		),
		'search'   => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
		),
		'box'      => array(
			'viewBox' => '0 0 24 24',
			'markup'  => '<path d="M21 8 12 3 3 8v8l9 5 9-5V8z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
		),
	);
}

/**
 * SVG-иконка.
 *
 * @param string $name  Имя.
 * @param string $class Дополнительный класс.
 * @return string
 */
function konstanta_icon( $name, $class = '' ) {
	$icons = konstanta_icons();
	if ( empty( $icons[ $name ] ) ) {
		return '';
	}

	$icon = $icons[ $name ];
	$fill = ! empty( $icon['fill'] );
	$css  = 'icon' . ( $fill ? ' icon--fill' : '' );

	if ( $class ) {
		$css .= ' ' . $class;
	}

	return sprintf(
		'<svg class="%1$s" viewBox="%2$s" aria-hidden="true" focusable="false">%3$s</svg>',
		esc_attr( $css ),
		esc_attr( $icon['viewBox'] ),
		$icon['markup']
	);
}

/**
 * Логотип-монограмма.
 *
 * @param string $class Класс.
 * @return string
 */
function konstanta_logo_mark( $class = 'logo__mark' ) {
	static $counter = 0;
	$counter++;
	$gradient = 'konstanta-logo-grad-' . $counter;

	return sprintf(
		'<svg class="%1$s" viewBox="0 0 40 40" aria-hidden="true" focusable="false"><defs><linearGradient id="%2$s" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#F2A65A"/><stop offset="1" stop-color="#D96B2B"/></linearGradient></defs><rect width="40" height="40" rx="12" fill="url(#%2$s)"/><path d="M13 11h5v6.6L24.4 11H30l-7.5 8.6L30.4 29h-6.3l-6.1-7.4V29h-5z" fill="#0B0E11"/></svg>',
		esc_attr( $class ),
		esc_attr( $gradient )
	);
}

/**
 * URL изображения.
 *
 * @param int    $attachment_id ID вложения.
 * @param string $fallback      Относительный путь в assets/img.
 * @return string
 */
function konstanta_image_url( $attachment_id, $fallback = '' ) {
	if ( $attachment_id ) {
		$url = wp_get_attachment_image_url( (int) $attachment_id, 'full' );
		if ( $url ) {
			return $url;
		}
	}

	if ( $fallback ) {
		return KONSTANTA_URI . '/assets/img/' . ltrim( $fallback, '/' );
	}

	return '';
}

/**
 * HTML изображения.
 *
 * @param int    $attachment_id ID вложения.
 * @param string $fallback      Относительный путь в assets/img.
 * @param string $alt           Alt.
 * @param string $class         CSS-класс.
 * @param array  $attr          Доп. атрибуты.
 * @return string
 */
function konstanta_image_html( $attachment_id, $fallback = '', $alt = '', $class = '', $attr = array() ) {
	if ( $attachment_id ) {
		$attr = array_merge(
			array(
				'class'   => $class,
				'alt'     => $alt,
				'loading' => 'lazy',
			),
			$attr
		);

		return wp_get_attachment_image( (int) $attachment_id, 'full', false, $attr );
	}

	$url = konstanta_image_url( 0, $fallback );
	if ( ! $url ) {
		return '';
	}

	$attr = array_merge(
		array(
			'src'     => $url,
			'alt'     => $alt,
			'class'   => $class,
			'loading' => 'lazy',
		),
		$attr
	);

	$attributes = '';
	foreach ( $attr as $name => $value ) {
		if ( '' === $value ) {
			continue;
		}
		$attributes .= ' ' . $name . '="' . esc_attr( $value ) . '"';
	}

	return '<img' . $attributes . '>';
}

/**
 * Пункты меню в виде ссылок без ul/li.
 *
 * @param string $location Локация меню.
 * @param array  $fallback Массив [label, url].
 */
function konstanta_nav_menu( $location = 'primary', $fallback = array() ) {
	$locations = get_nav_menu_locations();
	$menu_id   = isset( $locations[ $location ] ) ? (int) $locations[ $location ] : 0;

	if ( $menu_id ) {
		$items = wp_get_nav_menu_items( $menu_id );
		if ( $items ) {
			foreach ( $items as $item ) {
				printf(
					'<a class="nav__link" href="%1$s">%2$s</a>',
					esc_url( $item->url ),
					esc_html( $item->title )
				);
			}
			return;
		}
	}

	foreach ( $fallback as $item ) {
		printf(
			'<a class="nav__link" href="%1$s">%2$s</a>',
			esc_url( $item[1] ),
			esc_html( $item[0] )
		);
	}
}

/**
 * Краткое описание записи.
 *
 * @param int $post_id ID.
 * @param int $words   Количество слов.
 * @return string
 */
function konstanta_excerpt( $post_id, $words = 20 ) {
	$post = get_post( $post_id );
	if ( ! $post ) {
		return '';
	}

	$excerpt = $post->post_excerpt;
	if ( ! $excerpt ) {
		$excerpt = $post->post_content;
	}

	$excerpt = wp_strip_all_tags( strip_shortcodes( $excerpt ) );

	return wp_trim_words( $excerpt, $words, '…' );
}

/**
 * Строка в массив.
 *
 * @param mixed $value Значение.
 * @return array
 */
function konstanta_to_array( $value ) {
	if ( is_array( $value ) ) {
		return $value;
	}

	if ( is_string( $value ) && '' !== trim( $value ) ) {
		$lines = preg_split( '/\r\n|\r|\n/', $value );
		return array_values( array_filter( array_map( 'trim', $lines ) ) );
	}

	return array();
}
