<?php
/**
 * Основной шаблон архива.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<section class="section page-section">
	<div class="container page-container">
		<?php if ( is_home() && ! is_front_page() ) : ?>
			<h1 class="page-title"><?php single_post_title(); ?></h1>
		<?php elseif ( is_archive() ) : ?>
			<h1 class="page-title"><?php the_archive_title(); ?></h1>
			<?php the_archive_description( '<div class="entry-content">', '</div>' ); ?>
		<?php elseif ( is_search() ) : ?>
			<h1 class="page-title">Результаты поиска: <?php echo esc_html( get_search_query() ); ?></h1>
		<?php endif; ?>

		<?php if ( have_posts() ) : ?>
			<div class="archive-list">
				<?php while ( have_posts() ) : ?>
					<?php the_post(); ?>
					<article <?php post_class( 'archive-item' ); ?>>
						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<div class="entry-content"><?php the_excerpt(); ?></div>
					</article>
				<?php endwhile; ?>
			</div>

			<div class="pagination">
				<?php the_posts_pagination(); ?>
			</div>
		<?php else : ?>
			<p>Записей пока нет.</p>
		<?php endif; ?>
	</div>
</section>
<?php
get_footer();
