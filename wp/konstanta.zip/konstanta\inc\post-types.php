<?php
/**
 * Типы записей и таксономии.
 *
 * @package Konstanta
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Регистрация типов записей.
 */
function konstanta_register_post_types() {
	register_post_type(
		'material',
		array(
			'labels'              => array(
				'name'               => 'Материалы',
				'singular_name'      => 'Материал',
				'menu_name'          => 'Материалы',
				'add_new'            => 'Добавить материал',
				'add_new_item'       => 'Новый материал',
				'edit_item'          => 'Редактировать материал',
				'new_item'           => 'Новый материал',
				'view_item'          => 'Посмотреть материал',
				'search_items'       => 'Искать материалы',
				'not_found'          => 'Материалы не найдены',
				'not_found_in_trash' => 'В корзине материалов нет',
			),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_rest'        => true,
			'menu_position'       => 21,
			'menu_icon'           => 'dashicons-screenoptions',
			'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
			'taxonomies'          => array( 'material_category' ),
			'has_archive'         => false,
			'publicly_queryable'  => false,
			'exclude_from_search' => true,
		)
	);

	register_taxonomy(
		'material_category',
		array( 'material' ),
		array(
			'labels'            => array(
				'name'          => 'Категории материалов',
				'singular_name' => 'Категория',
				'add_new_item'  => 'Добавить категорию',
				'edit_item'     => 'Редактировать категорию',
				'search_items'  => 'Искать категории',
				'all_items'     => 'Все категории',
			),
			'public'            => false,
			'show_ui'           => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'rewrite'           => false,
		)
	);

	register_post_type(
		'vehicle',
		array(
			'labels'              => array(
				'name'               => 'Транспорт',
				'singular_name'      => 'Автомобиль',
				'menu_name'          => 'Транспорт',
				'add_new'            => 'Добавить авто',
				'add_new_item'       => 'Новый автомобиль',
				'edit_item'          => 'Редактировать автомобиль',
				'new_item'           => 'Новый автомобиль',
				'search_items'       => 'Искать транспорт',
				'not_found'          => 'Транспорт не найден',
				'not_found_in_trash' => 'В корзине транспорта нет',
			),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_rest'        => true,
			'menu_position'       => 22,
			'menu_icon'           => 'dashicons-car',
			'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
			'has_archive'         => false,
			'publicly_queryable'  => false,
			'exclude_from_search' => true,
		)
	);

	register_post_type(
		'faq',
		array(
			'labels'              => array(
				'name'               => 'Вопросы FAQ',
				'singular_name'      => 'Вопрос',
				'menu_name'          => 'FAQ',
				'add_new'            => 'Добавить вопрос',
				'add_new_item'       => 'Новый вопрос',
				'edit_item'          => 'Редактировать вопрос',
				'new_item'           => 'Новый вопрос',
				'search_items'       => 'Искать вопросы',
				'not_found'          => 'Вопросы не найдены',
				'not_found_in_trash' => 'В корзине вопросов нет',
			),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_rest'        => true,
			'menu_position'       => 23,
			'menu_icon'           => 'dashicons-editor-help',
			'supports'            => array( 'title', 'editor', 'page-attributes' ),
			'has_archive'         => false,
			'publicly_queryable'  => false,
			'exclude_from_search' => true,
		)
	);

	register_post_type(
		'request',
		array(
			'labels'              => array(
				'name'               => 'Заявки',
				'singular_name'      => 'Заявка',
				'menu_name'          => 'Заявки',
				'edit_item'          => 'Заявка',
				'view_item'          => 'Посмотреть заявку',
				'search_items'       => 'Искать заявки',
				'not_found'          => 'Заявок пока нет',
				'not_found_in_trash' => 'В корзине заявок нет',
			),
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_rest'        => false,
			'menu_position'       => 24,
			'menu_icon'           => 'dashicons-email-alt',
			'supports'            => array( 'title' ),
			'capability_type'     => 'post',
			'has_archive'         => false,
			'publicly_queryable'  => false,
			'exclude_from_search' => true,
		)
	);
}
add_action( 'init', 'konstanta_register_post_types' );

/**
 * Подсказки в полях заголовков.
 *
 * @param string  $text Текст.
 * @param WP_Post $post Запись.
 * @return string
 */
function konstanta_enter_title_here( $text, $post ) {
	if ( 'material' === $post->post_type ) {
		return 'Название материала';
	}
	if ( 'vehicle' === $post->post_type ) {
		return 'Название автомобиля';
	}
	if ( 'faq' === $post->post_type ) {
		return 'Вопрос клиента';
	}

	return $text;
}
add_filter( 'enter_title_here', 'konstanta_enter_title_here', 10, 2 );

/**
 * Метабокс параметров автомобиля.
 */
function konstanta_add_vehicle_meta_box() {
	add_meta_box(
		'konstanta_vehicle_details',
		'Параметры автомобиля',
		'konstanta_render_vehicle_meta_box',
		'vehicle',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'konstanta_add_vehicle_meta_box' );

/**
 * Вывод метабокса автомобиля.
 *
 * @param WP_Post $post Запись.
 */
function konstanta_render_vehicle_meta_box( $post ) {
	wp_nonce_field( 'konstanta_vehicle_meta', 'konstanta_vehicle_nonce' );
	$capacity = get_post_meta( $post->ID, '_konstanta_vehicle_capacity', true );
	$features = get_post_meta( $post->ID, '_konstanta_vehicle_features', true );
	?>
	<p>
		<label for="konstanta_vehicle_capacity"><strong>Грузоподъёмность / бейдж</strong></label><br>
		<input type="text" class="widefat" id="konstanta_vehicle_capacity" name="konstanta_vehicle_capacity" value="<?php echo esc_attr( $capacity ); ?>" placeholder="до 5 тонн">
	</p>
	<p>
		<label for="konstanta_vehicle_features"><strong>Характеристики</strong> — по одной на строку</label><br>
		<textarea class="widefat" rows="5" id="konstanta_vehicle_features" name="konstanta_vehicle_features" placeholder="Вывоз: бесплатно"><?php echo esc_textarea( $features ); ?></textarea>
	</p>
	<?php
}

/**
 * Сохранение метабокса автомобиля.
 *
 * @param int $post_id ID записи.
 */
function konstanta_save_vehicle_meta( $post_id ) {
	if ( ! isset( $_POST['konstanta_vehicle_nonce'] ) ) {
		return;
	}

	$nonce = sanitize_text_field( wp_unslash( $_POST['konstanta_vehicle_nonce'] ) );
	if ( ! wp_verify_nonce( $nonce, 'konstanta_vehicle_meta' ) ) {
		return;
	}

	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}

	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$capacity = isset( $_POST['konstanta_vehicle_capacity'] ) ? sanitize_text_field( wp_unslash( $_POST['konstanta_vehicle_capacity'] ) ) : '';
	$features = isset( $_POST['konstanta_vehicle_features'] ) ? sanitize_textarea_field( wp_unslash( $_POST['konstanta_vehicle_features'] ) ) : '';

	update_post_meta( $post_id, '_konstanta_vehicle_capacity', $capacity );
	update_post_meta( $post_id, '_konstanta_vehicle_features', $features );
}
add_action( 'save_post_vehicle', 'konstanta_save_vehicle_meta' );

/**
 * Метабокс заявки.
 */
function konstanta_add_request_meta_box() {
	add_meta_box(
		'konstanta_request_details',
		'Данные заявки',
		'konstanta_render_request_meta_box',
		'request',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'konstanta_add_request_meta_box' );

/**
 * Вывод данных заявки.
 *
 * @param WP_Post $post Запись.
 */
function konstanta_render_request_meta_box( $post ) {
	$data = get_post_meta( $post->ID, '_konstanta_request_data', true );
	if ( ! is_array( $data ) ) {
		echo '<p>Данные не найдены.</p>';
		return;
	}

	$rows = array(
		'Имя'       => isset( $data['name'] ) ? $data['name'] : '',
		'Телефон'   => isset( $data['phone'] ) ? $data['phone'] : '',
		'Категория' => isset( $data['category'] ) ? $data['category'] : '',
		'Объём'     => isset( $data['weight'] ) ? $data['weight'] : '',
		'Комментарий' => isset( $data['comment'] ) ? $data['comment'] : '',
		'Страница'  => isset( $data['page'] ) ? $data['page'] : '',
		'IP'        => isset( $data['ip'] ) ? $data['ip'] : '',
	);

	echo '<table class="widefat striped"><tbody>';
	foreach ( $rows as $label => $value ) {
		if ( '' === $value ) {
			continue;
		}
		echo '<tr><th style="width:160px">' . esc_html( $label ) . '</th><td>' . nl2br( esc_html( $value ) ) . '</td></tr>';
	}
	echo '</tbody></table>';

	if ( ! empty( $data['files'] ) && is_array( $data['files'] ) ) {
		echo '<p><strong>Файлы:</strong></p><ul>';
		foreach ( $data['files'] as $file ) {
			$url = isset( $file['url'] ) ? $file['url'] : '';
			$name = isset( $file['name'] ) ? $file['name'] : $url;
			if ( $url ) {
				echo '<li><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $name ) . '</a></li>';
			}
		}
		echo '</ul>';
	}
}
add_action( 'add_meta_boxes', 'konstanta_add_request_meta_box' );

/**
 * Колонки списка заявок.
 *
 * @param array $columns Колонки.
 * @return array
 */
function konstanta_request_columns( $columns ) {
	$new = array();
	foreach ( $columns as $key => $label ) {
		$new[ $key ] = $label;
		if ( 'title' === $key ) {
			$new['request_phone']    = 'Телефон';
			$new['request_category'] = 'Категория';
			$new['request_weight']   = 'Объём';
			$new['request_files']    = 'Файлы';
		}
	}
	return $new;
}
add_filter( 'manage_request_posts_columns', 'konstanta_request_columns' );

/**
 * Значения колонок заявок.
 *
 * @param string $column  Колонка.
 * @param int    $post_id ID.
 */
function konstanta_request_column_content( $column, $post_id ) {
	$data = get_post_meta( $post_id, '_konstanta_request_data', true );
	if ( ! is_array( $data ) ) {
		return;
	}

	if ( 'request_phone' === $column ) {
		echo esc_html( isset( $data['phone'] ) ? $data['phone'] : '' );
	}
	if ( 'request_category' === $column ) {
		echo esc_html( isset( $data['category'] ) ? $data['category'] : '' );
	}
	if ( 'request_weight' === $column ) {
		echo esc_html( isset( $data['weight'] ) ? $data['weight'] : '' );
	}
	if ( 'request_files' === $column ) {
		echo ! empty( $data['files'] ) ? (int) count( $data['files'] ) : '0';
	}
}
add_action( 'manage_request_posts_custom_column', 'konstanta_request_column_content', 10, 2 );
